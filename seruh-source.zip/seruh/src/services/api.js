// ─────────────────────────────────────────────────────────────
// Data service layer.
//
//   UI components  →  api (this module)  →  Supabase (Postgres)
//                                        ↘  Local fallback (demo)
//
// Every UI feature talks only to this interface, so the backend
// can be swapped (API server, other DB, CMS) without touching
// components. When Supabase isn't configured yet, a local demo
// implementation keeps the whole site working.
// ─────────────────────────────────────────────────────────────

import { supabase } from '../lib/supabase'
import { isBackendConfigured } from '../lib/config'
import { getVisitorId } from '../lib/visitor'
import { QUOTES, CATEGORIES } from '../data/quotes'

const PAGE_SIZE = 12

/* ═══════════════════════ Supabase implementation ═══════════════════════ */

const SupabaseApi = {
  mode: 'supabase',

  async getCategories() {
    const { data, error } = await supabase
      .from('categories_public').select('name').order('sort', { ascending: true })
    if (error) throw error
    return data.map(c => c.name)
  },

  async getQuotes({ page = 0, pageSize = PAGE_SIZE, category = null, search = '' } = {}) {
    let q = supabase.from('quotes_public')
      .select('id, quote, category, mood, author, tags, featured, like_count', { count: 'exact' })
      .order('created_at', { ascending: false })
    if (category) q = q.eq('category', category)
    const s = search.trim()
    if (s) q = q.ilike('search_text', `%${s}%`)
    const from = page * pageSize
    const { data, count, error } = await q.range(from, from + pageSize - 1)
    if (error) throw error
    return { items: data, total: count ?? data.length }
  },

  async getRandomQuote(excludeId = null) {
    const { data, error } = await supabase.rpc('get_random_quote', { p_exclude: excludeId })
    if (error) throw error
    return data
  },

  async getTodaysFeeling() {
    const { data, error } = await supabase.rpc('get_todays_feeling')
    if (error) throw error
    return data
  },

  async getMyActivity() {
    const { data, error } = await supabase.rpc('get_my_activity', { p_visitor: getVisitorId() })
    if (error) throw error
    return data
  },

  async toggleQuoteLike(quoteId) {
    const { data, error } = await supabase.rpc('toggle_quote_like', {
      p_quote: quoteId, p_visitor: getVisitorId(),
    })
    if (error) throw error
    return data // { liked, count }
  },

  async toggleQuoteSave(quoteId) {
    const { data, error } = await supabase.rpc('toggle_quote_save', {
      p_quote: quoteId, p_visitor: getVisitorId(),
    })
    if (error) throw error
    return data // { saved }
  },

  async getSavedQuotes() {
    const { data, error } = await supabase.rpc('get_saved_quotes', { p_visitor: getVisitorId() })
    if (error) throw error
    return data ?? []
  },

  async getPublicFeelings({ page = 0, pageSize = 10 } = {}) {
    let q = supabase.from('feelings_public')
      .select('id, content, category, mood, display_name, created_at, like_count', { count: 'exact' })
      .order('created_at', { ascending: false })
    const from = page * pageSize
    const { data, count, error } = await q.range(from, from + pageSize - 1)
    if (error) throw error
    return { items: data, total: count ?? data.length }
  },

  async toggleFeelingLike(feelingId) {
    const { data, error } = await supabase.rpc('toggle_feeling_like', {
      p_feeling: feelingId, p_visitor: getVisitorId(),
    })
    if (error) throw error
    return data
  },

  async submitFeeling({ content, category, mood, anonymous, name, email, honeypot }) {
    const { error } = await supabase.rpc('submit_feeling', {
      p_content: content, p_category: category, p_mood: mood,
      p_anonymous: !!anonymous, p_name: name || null, p_email: email || null,
      p_visitor: getVisitorId(), p_honey: honeypot || '',
    })
    if (error) throw error
    return { ok: true }
  },

  /* ── Phase 3: AI generation (via Edge Function — key stays server-side) ── */

  async generateQuote({ feeling, mood, style, length }) {
    const { data, error } = await supabase.functions.invoke('ai-generate', {
      body: { feeling, mood, style, length, visitor_id: getVisitorId() },
    })
    if (error) {
      let body = null
      try { body = await error.context?.json?.() } catch { /* opaque */ }
      if (body?.limited || body?.blocked) return body
      throw new Error(body?.message || 'generation failed')
    }
    return data // { quote, generation_id, remaining } | { blocked, message }
  },

  async getMyGenerations() {
    const { data, error } = await supabase.rpc('get_my_generations', { p_visitor: getVisitorId() })
    if (error) throw error
    return data ?? []
  },

  async setGenerationSaved(id, saved) {
    const { error } = await supabase.rpc('set_generation_saved', { p_id: id, p_visitor: getVisitorId(), p_saved: saved })
    if (error) throw error
  },

  async deleteGeneration(id) {
    const { error } = await supabase.rpc('delete_generation', { p_id: id, p_visitor: getVisitorId() })
    if (error) throw error
  },

  /* ── Phase 3: personal data & recommendations ── */

  async getMySubmissions() {
    const { data, error } = await supabase.rpc('get_my_submissions', { p_visitor: getVisitorId() })
    if (error) throw error
    return data ?? []
  },

  async getMyLikedQuotes() {
    const { data, error } = await supabase.rpc('get_my_liked_quotes', { p_visitor: getVisitorId() })
    if (error) throw error
    return data ?? []
  },

  async getMyActivityFeed() {
    const { data, error } = await supabase.rpc('get_my_activity_feed', { p_visitor: getVisitorId() })
    if (error) throw error
    return data ?? []
  },

  async getRecommendedQuotes(limit = 3) {
    const { data, error } = await supabase.rpc('get_recommended_quotes', { p_visitor: getVisitorId(), p_limit: limit })
    if (error) throw error
    return data ?? []
  },

  /* fire-and-forget analytics (aggregate counts only, no feeling text) */
  track(event, entityType = null, entityId = null, meta = {}) {
    try {
      supabase.rpc('track_event', {
        p_event: event, p_entity_type: entityType,
        p_entity_id: entityId ? String(entityId) : null,
        p_visitor: getVisitorId(), p_meta: meta,
      }).then(() => {}, () => {})
    } catch { /* never break the UI for analytics */ }
  },
}

/* ═══════════════════════ Local demo implementation ═══════════════════════
   Used before the Supabase backend is connected. Likes/saves live in this
   browser only; submissions fall back to the Netlify form when deployed. */

const LS = {
  get(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback } catch { return fallback }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)) } catch { /* private mode */ }
  },
}

const SEED_FEELINGS = [
  { id: 'f1', content: "I still check my phone sometimes, knowing there won't be a message.", category: 'Unsaid Things', mood: 'Lonely', display_name: 'Anonymous', created_at: '2026-08-20T21:14:00Z', like_count: 42 },
  { id: 'f2', content: 'I forgave you long ago. I just never found a reason to tell you.', category: 'Healing', mood: 'Peaceful', display_name: 'Anonymous', created_at: '2026-08-18T02:40:00Z', like_count: 31 },
  { id: 'f3', content: 'Some days I miss the person I was before I learned to be careful.', category: 'Memories', mood: 'Nostalgic', display_name: 'Anonymous', created_at: '2026-08-15T23:05:00Z', like_count: 57 },
  { id: 'f4', content: 'I hope the version of me you remember is kind to you.', category: 'Heartfelt', mood: 'Emotional', display_name: 'Anonymous', created_at: '2026-08-12T20:22:00Z', like_count: 24 },
]

const baseCount = id => 23 + ((id * 37) % 180)

// Original demo lines for the local (pre-backend) word-weaver.
const DEMO_GENERATIONS = {
  Sad: [
    'Some goodbyes keep living quietly inside the hello you never sent.',
    'The heart heals in its own handwriting — slow, crooked, and honest.',
  ],
  Lonely: [
    'Even empty rooms remember the shape of the people we miss.',
    'Loneliness is just love that hasn’t found its address yet.',
  ],
  Hopeful: [
    'Whatever you are becoming is already on its way to meet you.',
    'Some mornings arrive early, just to prove the night wrong.',
  ],
  Romantic: [
    'You are the sentence my heart keeps starting and never wants to finish.',
    'Somewhere between your name and my silence, a whole story lives.',
  ],
  Nostalgic: [
    'We never lose the old days — we just learn to visit them with our eyes closed.',
    'Some memories don’t fade; they simply learn to whisper.',
  ],
  Peaceful: [
    'Let today be soft. Not everything needs an answer by evening.',
    'Stillness is not empty — it is where you finally hear yourself.',
  ],
  Emotional: [
    'What you feel deeply was never meant to fit into small words.',
    'Sometimes moving on isn’t about forgetting someone. It’s about remembering yourself.',
  ],
  Grateful: [
    'Some people are quiet blessings wearing ordinary days.',
    'Thank the small moments — they carried you here.',
  ],
}

function localQuote(q) {
  const likes = LS.get('seruh_likes', {})
  return {
    id: q.id, quote: q.quote, category: q.category, mood: q.mood,
    author: q.author, tags: q.tags, featured: q.featured,
    like_count: baseCount(q.id) + (likes[q.id] ? 1 : 0),
  }
}

const LocalApi = {
  mode: 'local',

  async getCategories() {
    return CATEGORIES.map(c => c.label)
  },

  async getQuotes({ page = 0, pageSize = PAGE_SIZE, category = null, search = '' } = {}) {
    const s = search.trim().toLowerCase()
    const all = QUOTES.filter(item => {
      if (category && item.category !== category) return false
      if (!s) return true
      return [item.quote, item.category, item.mood, item.author ?? '', ...(item.tags ?? [])]
        .join(' ').toLowerCase().includes(s)
    })
    const from = page * pageSize
    return { items: all.slice(from, from + pageSize).map(localQuote), total: all.length }
  },

  async getRandomQuote(excludeId = null) {
    const pool = QUOTES.filter(q => q.id !== excludeId)
    return localQuote(pool[Math.floor(Math.random() * pool.length)])
  },

  async getTodaysFeeling() {
    const featured = QUOTES.filter(q => q.featured)
    const pool = featured.length ? featured : QUOTES
    return localQuote(pool[Math.floor(Math.random() * pool.length)])
  },

  async getMyActivity() {
    const likes = LS.get('seruh_likes', {})
    const saves = LS.get('seruh_saves', {})
    const flikes = LS.get('seruh_feeling_likes', {})
    return {
      liked_quote_ids: Object.keys(likes).map(Number),
      saved: Object.entries(saves).map(([quote_id, saved_at]) => ({ quote_id: Number(quote_id), saved_at })),
      liked_feeling_ids: Object.keys(flikes),
    }
  },

  async toggleQuoteLike(quoteId) {
    const likes = LS.get('seruh_likes', {})
    const liked = !likes[quoteId]
    if (liked) likes[quoteId] = true; else delete likes[quoteId]
    LS.set('seruh_likes', likes)
    return { liked, count: baseCount(quoteId) + (liked ? 1 : 0) }
  },

  async toggleQuoteSave(quoteId) {
    const saves = LS.get('seruh_saves', {})
    const saved = !saves[quoteId]
    if (saved) saves[quoteId] = new Date().toISOString(); else delete saves[quoteId]
    LS.set('seruh_saves', saves)
    return { saved }
  },

  async getSavedQuotes() {
    const saves = LS.get('seruh_saves', {})
    return Object.entries(saves)
      .map(([id, saved_at]) => {
        const q = QUOTES.find(x => x.id === Number(id))
        return q ? { ...localQuote(q), saved_at } : null
      })
      .filter(Boolean)
      .sort((a, b) => (a.saved_at < b.saved_at ? 1 : -1))
  },

  async getPublicFeelings() {
    const flikes = LS.get('seruh_feeling_likes', {})
    return {
      items: SEED_FEELINGS.map(f => ({ ...f, like_count: f.like_count + (flikes[f.id] ? 1 : 0) })),
      total: SEED_FEELINGS.length,
    }
  },

  async toggleFeelingLike(feelingId) {
    const flikes = LS.get('seruh_feeling_likes', {})
    const liked = !flikes[feelingId]
    if (liked) flikes[feelingId] = true; else delete flikes[feelingId]
    LS.set('seruh_feeling_likes', flikes)
    const seed = SEED_FEELINGS.find(f => f.id === feelingId)
    return { liked, count: (seed?.like_count ?? 0) + (liked ? 1 : 0) }
  },

  /* ── Phase 3 (demo): a tiny local word-weaver so the flow can be
        felt before the real AI backend is connected ── */

  async generateQuote({ feeling, mood, style, length }) {
    await new Promise(r => setTimeout(r, 900))
    const pool = DEMO_GENERATIONS[mood] ?? Object.values(DEMO_GENERATIONS).flat()
    const hist = LS.get('seruh_generations', [])
    const last = hist[0]?.generated_text
    const options = pool.filter(q => q !== last)
    const quote = options[Math.floor(Math.random() * options.length)] ?? pool[0]
    const id = `demo-${Date.now()}`
    hist.unshift({
      id, input_text: (feeling || '').slice(0, 500), mood: mood || null,
      style: style || null, length: length || null,
      generated_text: quote, saved: false, created_at: new Date().toISOString(),
    })
    LS.set('seruh_generations', hist.slice(0, 50))
    return { quote, generation_id: id, remaining: 99, demo: true }
  },

  async getMyGenerations() { return LS.get('seruh_generations', []) },

  async setGenerationSaved(id, saved) {
    const hist = LS.get('seruh_generations', [])
    const item = hist.find(g => g.id === id)
    if (item) { item.saved = saved; LS.set('seruh_generations', hist) }
  },

  async deleteGeneration(id) {
    LS.set('seruh_generations', LS.get('seruh_generations', []).filter(g => g.id !== id))
  },

  async getMySubmissions() { return [] },

  async getMyLikedQuotes() {
    const likes = LS.get('seruh_likes', {})
    return QUOTES.filter(q => likes[q.id]).map(q => ({ ...localQuote(q), liked_at: null }))
  },

  async getMyActivityFeed() {
    const likes = LS.get('seruh_likes', {})
    const saves = LS.get('seruh_saves', {})
    const feed = []
    Object.keys(likes).forEach(id => {
      const q = QUOTES.find(x => x.id === Number(id))
      if (q) feed.push({ label: 'liked a quote', detail: q.quote.split('\n')[0], created_at: null })
    })
    Object.entries(saves).forEach(([id, at]) => {
      const q = QUOTES.find(x => x.id === Number(id))
      if (q) feed.push({ label: 'saved a quote', detail: q.quote.split('\n')[0], created_at: at })
    })
    return feed.slice(0, 25)
  },

  async getRecommendedQuotes(limit = 3) {
    const likes = LS.get('seruh_likes', {})
    const saves = LS.get('seruh_saves', {})
    const likedCats = new Set(QUOTES.filter(q => likes[q.id] || saves[q.id]).map(q => q.category))
    const pool = QUOTES.filter(q => !likes[q.id] && !saves[q.id])
    pool.sort((a, b) => (likedCats.has(b.category) ? 1 : 0) - (likedCats.has(a.category) ? 1 : 0) || Math.random() - 0.5)
    return pool.slice(0, limit).map(localQuote)
  },

  track() { /* analytics need the backend — no-op in demo mode */ },

  async submitFeeling({ content, category, mood, anonymous, name, email, honeypot }) {
    // Demo fallback: post to the Netlify form so submissions still reach
    // the site owner's email until the database backend is connected.
    const body = new URLSearchParams({
      'form-name': 'seruh-feelings',
      name: anonymous ? '' : (name || ''),
      email: email || '',
      quote: content,
      category, mood,
      anonymous: anonymous ? 'Yes' : 'No',
      'bot-field': honeypot || '',
    })
    const res = await fetch('/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
    })
    if (!res.ok) throw new Error('submit failed')
    return { ok: true }
  },
}

export const api = isBackendConfigured ? SupabaseApi : LocalApi
export const BACKEND_MODE = api.mode
