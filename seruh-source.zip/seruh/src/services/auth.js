// Authentication service — wraps Supabase Auth (secure password
// hashing, tokens and sessions are handled server-side by Supabase).
// In demo mode (no backend), accounts are unavailable.

import { supabase } from '../lib/supabase'
import { isBackendConfigured } from '../lib/config'
import { getVisitorId } from '../lib/visitor'

const unavailable = () => { throw new Error('auth-unavailable') }

export const auth = isBackendConfigured ? {
  available: true,

  async signUp({ name, email, password }) {
    const { data, error } = await supabase.auth.signUp({
      email, password,
      options: { data: { name } },
    })
    if (error) throw error
    return { needsConfirm: !data.session }
  },

  async signIn(email, password) {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    await supabase.from('profiles').update({ last_login_at: new Date().toISOString() })
      .eq('user_id', (await supabase.auth.getUser()).data.user.id)
  },

  async signOut() { await supabase.auth.signOut() },

  async getSession() { return (await supabase.auth.getSession()).data.session },

  onAuth(cb) {
    const { data } = supabase.auth.onAuthStateChange((_e, session) => cb(session))
    return () => data?.subscription?.unsubscribe?.()
  },

  async getProfile() {
    const { data: u } = await supabase.auth.getUser()
    if (!u?.user) return null
    const { data } = await supabase.from('profiles').select('*').eq('user_id', u.user.id).maybeSingle()
    return { id: u.user.id, email: u.user.email, name: data?.name ?? u.user.user_metadata?.name ?? '', onboarding: data?.onboarding ?? {} }
  },

  async updateName(name) {
    const { data: u } = await supabase.auth.getUser()
    const { error } = await supabase.from('profiles')
      .update({ name: name.trim().slice(0, 80), updated_at: new Date().toISOString() })
      .eq('user_id', u.user.id)
    if (error) throw error
  },

  async updateEmail(email) {
    const { error } = await supabase.auth.updateUser({ email })
    if (error) throw error
  },

  async updatePassword(password) {
    const { error } = await supabase.auth.updateUser({ password })
    if (error) throw error
  },

  async getPreferences() {
    const { data: u } = await supabase.auth.getUser()
    if (!u?.user) return null
    const { data } = await supabase.from('user_preferences').select('*').eq('user_id', u.user.id).maybeSingle()
    return data ?? {}
  },

  async savePreferences(patch) {
    const { data: u } = await supabase.auth.getUser()
    const { error } = await supabase.from('user_preferences')
      .upsert({ user_id: u.user.id, ...patch, updated_at: new Date().toISOString() })
    if (error) throw error
  },

  async saveOnboarding(onboarding) {
    const { data: u } = await supabase.auth.getUser()
    await supabase.from('profiles').update({ onboarding }).eq('user_id', u.user.id)
  },

  async mergeVisitorData() {
    const { error } = await supabase.rpc('merge_visitor_data', { p_visitor: getVisitorId() })
    if (error) throw error
  },

  async deleteAccount() {
    const { error } = await supabase.rpc('delete_my_account')
    if (error) throw error
    await supabase.auth.signOut()
  },
} : {
  available: false,
  signUp: unavailable, signIn: unavailable, signOut: async () => {},
  getSession: async () => null, onAuth: () => () => {},
  getProfile: async () => null, updateName: unavailable, updateEmail: unavailable,
  updatePassword: unavailable, getPreferences: async () => null,
  savePreferences: unavailable, saveOnboarding: async () => {},
  mergeVisitorData: async () => {}, deleteAccount: unavailable,
}
