import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Heart, Copy, Share2, Sparkles, Bookmark } from 'lucide-react'
import { api } from '../services/api'
import { useUi } from '../context/UiContext'
import { useData } from '../context/DataContext'
import { BigQuoteSkeleton } from './Skeleton'

export default function TodaysFeeling() {
  const [quote, setQuote] = useState(null)
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState(false)
  const { copyQuote, openShare } = useUi()
  const { likedQuotes, savedMap, toggleQuoteLike, toggleQuoteSave, likeCountOf } = useData()

  useEffect(() => {
    let alive = true
    api.getTodaysFeeling()
      .then(q => { if (alive) { setQuote(q); setLoading(false) } })
      .catch(() => { if (alive) { setFailed(true); setLoading(false) } })
    return () => { alive = false }
  }, [])

  const another = async () => {
    try {
      const next = await api.getRandomQuote(quote?.id ?? null)
      setQuote(next)
      setFailed(false)
    } catch {
      setFailed(true)
    }
  }

  const liked = quote ? likedQuotes.has(quote.id) : false
  const saved = quote ? savedMap.has(quote.id) : false

  return (
    <section id="today" className="relative py-24 sm:py-28 px-5">
      <div className="mx-auto max-w-3xl text-center">
        <motion.p
          initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
          className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-10"
        >
          ✨ Today&rsquo;s Feeling
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="relative rounded-[1.75rem] bg-card border border-linec px-7 py-14 sm:px-16 sm:py-16 shadow-xl shadow-charcoal/[0.05]"
        >
          <span aria-hidden="true" className="absolute top-5 left-6 font-display text-5xl leading-none text-rose/30 select-none">&ldquo;</span>
          <span aria-hidden="true" className="absolute bottom-3 right-6 font-display text-5xl leading-none text-rose/30 select-none rotate-180">&ldquo;</span>

          <div className="min-h-40 sm:min-h-36 flex items-center justify-center">
            {loading ? (
              <div className="w-full"><BigQuoteSkeleton /></div>
            ) : failed && !quote ? (
              <p className="font-body text-softink">The words are resting for a moment — please try again.</p>
            ) : (
              <AnimatePresence mode="wait">
                <motion.blockquote
                  key={quote.id}
                  initial={{ opacity: 0, y: 14, filter: 'blur(6px)' }}
                  animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, y: -12, filter: 'blur(6px)' }}
                  transition={{ duration: 0.55, ease: 'easeOut' }}
                  className="font-display text-[clamp(1.5rem,4vw,2.2rem)] leading-[1.45] text-charcoal whitespace-pre-line"
                >
                  {quote.quote}
                </motion.blockquote>
              </AnimatePresence>
            )}
          </div>

          {quote && (
            <>
              <p className="font-body text-sm tracking-[0.18em] text-softink mt-7">— {quote.author || 'SeRuh'}</p>

              <div className="mt-9 flex flex-wrap items-center justify-center gap-2.5">
                <button
                  onClick={() => toggleQuoteLike(quote)}
                  aria-pressed={liked}
                  aria-label={liked ? 'Unlike this feeling' : 'Like this feeling'}
                  className={`flex items-center gap-2 rounded-full border px-4.5 py-2.5 text-[0.85rem] tabular-nums transition-all duration-300 ${
                    liked ? 'border-rose bg-roseveil text-rosedeep' : 'border-linec text-softink hover:border-rose hover:text-rosedeep'
                  }`}
                >
                  <Heart size={15} className={liked ? 'fill-rose text-rose' : ''} aria-hidden="true" /> {likeCountOf(quote)}
                </button>
                <button
                  onClick={() => toggleQuoteSave(quote)}
                  aria-pressed={saved}
                  aria-label={saved ? 'Remove from saved' : 'Save for later'}
                  className={`flex items-center gap-2 rounded-full border px-4.5 py-2.5 text-[0.85rem] transition-all duration-300 ${
                    saved ? 'border-rose bg-roseveil text-rosedeep' : 'border-linec text-softink hover:border-rose hover:text-rosedeep'
                  }`}
                >
                  <Bookmark size={15} className={saved ? 'fill-rose text-rose' : ''} aria-hidden="true" /> {saved ? 'Saved' : 'Save'}
                </button>
                <button
                  onClick={() => copyQuote(quote)}
                  className="flex items-center gap-2 rounded-full border border-linec px-4.5 py-2.5 text-[0.85rem] text-softink hover:border-rose hover:text-rosedeep transition-colors duration-300"
                >
                  <Copy size={15} aria-hidden="true" /> Copy
                </button>
                <button
                  onClick={() => openShare(quote)}
                  className="flex items-center gap-2 rounded-full border border-linec px-4.5 py-2.5 text-[0.85rem] text-softink hover:border-rose hover:text-rosedeep transition-colors duration-300"
                >
                  <Share2 size={15} aria-hidden="true" /> Share
                </button>
                <button
                  onClick={another}
                  className="flex items-center gap-2 rounded-full bg-charcoal text-ivory px-5 py-2.5 text-[0.85rem] hover:bg-rosedeep transition-colors duration-300"
                >
                  <Sparkles size={15} aria-hidden="true" /> Another Feeling
                </button>
              </div>
            </>
          )}
        </motion.div>
      </div>
    </section>
  )
}
