import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X, ChevronDown, User } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

const LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'Explore', href: '#explore' },
  { label: "Today's Feeling", href: '#today' },
  { label: 'Find My Words', href: '#generate' },
  { label: 'Unsaid Feelings', href: '#unsaid' },
  { label: 'Our Story', href: '#story' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [menu, setMenu] = useState(false)
  const menuRef = useRef(null)
  const { user, available, openAuth, signOut } = useAuth()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenu(false) }
    document.addEventListener('click', close)
    return () => document.removeEventListener('click', close)
  }, [])

  const firstName = user?.name?.split(' ')[0] || 'You'

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? 'bg-ivory/85 backdrop-blur-md border-b border-linec shadow-sm shadow-charcoal/5' : 'bg-transparent'
      }`}
    >
      <nav aria-label="Main" className="mx-auto max-w-6xl px-5 sm:px-8 h-16 flex items-center justify-between gap-3">
        <a href="#home" className="font-display text-[1.65rem] font-medium tracking-wide text-charcoal shrink-0">
          Se<span className="text-rose">Ruh</span>
        </a>

        {/* desktop links */}
        <div className="hidden lg:flex items-center gap-0.5">
          {LINKS.map(l => (
            <a key={l.href} href={l.href}
              className="px-3 py-2 text-[0.84rem] text-softink hover:text-rosedeep rounded-full transition-colors whitespace-nowrap">
              {l.label}
            </a>
          ))}

          {user ? (
            <div className="relative ml-2" ref={menuRef}>
              <button
                onClick={() => setMenu(v => !v)}
                aria-expanded={menu} aria-haspopup="menu"
                className="flex items-center gap-2 rounded-full border border-linec bg-card px-4 py-2 text-[0.84rem] text-charcoal hover:border-rose transition-colors"
              >
                <User size={14} className="text-rose" aria-hidden="true" />
                {firstName}
                <ChevronDown size={13} aria-hidden="true" className={`transition-transform ${menu ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {menu && (
                  <motion.div
                    role="menu"
                    initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
                    transition={{ duration: 0.18 }}
                    className="absolute right-0 mt-2 w-52 rounded-2xl bg-card border border-linec shadow-xl shadow-charcoal/10 p-2"
                  >
                    {[
                      ['My SeRuh', '#/me'],
                      ['My Saved Feelings', '#/me/saved'],
                      ['My Generated Quotes', '#/me/generated'],
                      ['My Submissions', '#/me/submissions'],
                      ['Settings', '#/me/settings'],
                    ].map(([label, href]) => (
                      <a key={href} role="menuitem" href={href} onClick={() => setMenu(false)}
                        className="block rounded-xl px-3.5 py-2.5 text-[0.86rem] font-body text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors">
                        {label}
                      </a>
                    ))}
                    <button role="menuitem" onClick={() => { setMenu(false); signOut() }}
                      className="w-full text-left rounded-xl px-3.5 py-2.5 text-[0.86rem] font-body text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors">
                      Logout
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <>
              {available && (
                <button onClick={openAuth}
                  className="ml-2 px-3.5 py-2 text-[0.84rem] text-softink hover:text-rosedeep rounded-full border border-linec hover:border-rose transition-colors whitespace-nowrap">
                  Log in
                </button>
              )}
              <a href="#write"
                className="ml-2 rounded-full bg-charcoal text-ivory text-[0.84rem] px-4.5 py-2.5 hover:bg-rosedeep transition-colors whitespace-nowrap">
                Share a Feeling
              </a>
            </>
          )}
        </div>

        {/* mobile toggle */}
        <button
          className="lg:hidden p-2 rounded-full text-charcoal hover:bg-cream transition-colors"
          onClick={() => setOpen(v => !v)}
          aria-expanded={open}
          aria-label={open ? 'Close menu' : 'Open menu'}
        >
          {open ? <X size={22} aria-hidden="true" /> : <Menu size={22} aria-hidden="true" />}
        </button>
      </nav>

      {/* mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.32, ease: 'easeInOut' }}
            className="lg:hidden overflow-hidden bg-ivory/95 backdrop-blur-md border-b border-linec"
          >
            <div className="px-6 py-4 flex flex-col max-h-[75svh] overflow-y-auto">
              {LINKS.map(l => (
                <a key={l.href} href={l.href} onClick={() => setOpen(false)}
                  className="py-3 text-[0.95rem] text-charcoal border-b border-linec/60 hover:text-rosedeep transition-colors">
                  {l.label}
                </a>
              ))}
              {user ? (
                <>
                  <a href="#/me" onClick={() => setOpen(false)}
                    className="py-3 text-[0.95rem] text-rosedeep border-b border-linec/60">
                    My SeRuh — {firstName} ❤️
                  </a>
                  <button onClick={() => { setOpen(false); signOut() }}
                    className="py-3 text-left text-[0.95rem] text-softink hover:text-rosedeep transition-colors">
                    Logout
                  </button>
                </>
              ) : available ? (
                <button onClick={() => { setOpen(false); openAuth() }}
                  className="py-3 text-left text-[0.95rem] text-rosedeep">
                  Log in / Sign up
                </button>
              ) : null}
              <a href="#write" onClick={() => setOpen(false)}
                className="mt-3 mb-2 rounded-full bg-charcoal text-ivory text-center text-[0.92rem] px-5 py-3 hover:bg-rosedeep transition-colors">
                Share a Feeling
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}
