import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Bookmark, Copy, Share2, X } from 'lucide-react'
import { api } from '../services/api'
import { useUi } from '../context/UiContext'
import { useData } from '../context/DataContext'
import { RowSkeleton } from './Skeleton'

function fmtDate(iso) {
  try {
    return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
  } catch { return '' }
}

export default function SavedFeelings() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const { copyQuote, openShare } = useUi()
  const { savedMap, savedVersion, toggleQuoteSave } = useData()

  useEffect(() => {
    let alive = true
    api.getSavedQuotes()
      .then(list => { if (alive) { setItems(list); setLoading(false) } })
      .catch(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [savedVersion])

  const visible = items.filter(q => savedMap.has(q.id))

  return (
    <section id="saved" className="relative py-24 sm:py-28 px-5 bg-cream/60">
      <div className="mx-auto max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <p className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-4">Yours to keep</p>
          <h2 className="font-display text-[clamp(2.1rem,5vw,3rem)] text-charcoal">My Saved Feelings</h2>
        </motion.div>

        {loading ? (
          <RowSkeleton rows={3} />
        ) : visible.length === 0 ? (
          <div className="text-center py-10">
            <Bookmark size={30} aria-hidden="true" className="mx-auto text-faint mb-5" />
            <p className="font-display text-2xl text-charcoal mb-2.5">Nothing saved yet.</p>
            <p className="font-body text-softink mb-8">When a feeling speaks to you, keep it close.</p>
            <a
              href="#explore"
              className="inline-block rounded-full bg-charcoal text-ivory px-7 py-3 text-[0.92rem] hover:bg-rosedeep transition-colors duration-300"
            >
              Explore Feelings
            </a>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {visible.map(q => (
              <motion.article
                key={q.id}
                layout
                initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45 }}
                className="rounded-2xl bg-card border border-linec p-6 sm:p-7 flex flex-col sm:flex-row sm:items-start gap-4"
              >
                <div className="flex-1 min-w-0">
                  <blockquote className="font-display text-[1.15rem] leading-[1.55] text-charcoal whitespace-pre-line">
                    {q.quote}
                  </blockquote>
                  <p className="font-body text-[0.78rem] text-faint mt-3">
                    <span className="text-rose">#{q.category.replace(/\s+/g, '')}</span>
                    <span aria-hidden="true"> · </span><span className="italic">{q.mood}</span>
                    <span aria-hidden="true"> · </span>saved {fmtDate(savedMap.get(q.id) ?? q.saved_at)}
                  </p>
                </div>
                <div className="flex sm:flex-col gap-1 shrink-0">
                  <button
                    onClick={() => copyQuote(q)}
                    aria-label="Copy this quote"
                    className="p-2.5 rounded-full text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors"
                  >
                    <Copy size={16} aria-hidden="true" />
                  </button>
                  <button
                    onClick={() => openShare(q)}
                    aria-label="Share this quote"
                    className="p-2.5 rounded-full text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors"
                  >
                    <Share2 size={16} aria-hidden="true" />
                  </button>
                  <button
                    onClick={() => toggleQuoteSave(q)}
                    aria-label="Remove from saved"
                    className="p-2.5 rounded-full text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors"
                  >
                    <X size={16} aria-hidden="true" />
                  </button>
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
