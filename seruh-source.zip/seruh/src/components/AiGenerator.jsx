import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Sparkles, Heart, Bookmark, Copy, Share2 } from 'lucide-react'
import { api, BACKEND_MODE } from '../services/api'
import { useUi } from '../context/UiContext'
import { useAuth } from '../context/AuthContext'

const MOODS = ['Happy','Sad','Romantic','Peaceful','Lonely','Hopeful','Nostalgic','Emotional','Confused','Grateful','Angry','Motivated']
const STYLES = ['Short & Deep','Poetic','Romantic','Minimal','Emotional','Philosophical','Hopeful','Midnight']
const LENGTHS = ['One Line','Short','Medium']

export default function AiGenerator() {
  const { copyQuote, openShare, showToast } = useUi()
  const auth = useAuth()
  const [feeling, setFeeling] = useState('')
  const [mood, setMood] = useState(null)
  const [style, setStyle] = useState('Short & Deep')
  const [length, setLength] = useState('Short')
  const [state, setState] = useState('idle')   // idle | loading | done | blocked | limited
  const [result, setResult] = useState(null)   // { quote, generation_id, remaining, demo }
  const [notice, setNotice] = useState('')
  const [liked, setLiked] = useState(false)
  const [saved, setSaved] = useState(false)

  const generate = async () => {
    const text = feeling.trim()
    if (text.length < 3) { showToast("Tell SeRuh a little more about what you're feeling."); return }
    setState('loading'); setLiked(false); setSaved(false)
    try {
      const res = await api.generateQuote({ feeling: text, mood, style, length })
      if (res.limited) { setNotice(res.message); setState('limited'); return }
      if (res.blocked) { setNotice(res.message); setState('blocked'); return }
      setResult(res)
      setState('done')
    } catch {
      setNotice("SeRuh couldn't find the words this time. Please try again. ❤️")
      setState('blocked')
    }
  }

  const saveIt = async () => {
    if (!result?.generation_id) return
    try {
      await api.setGenerationSaved(result.generation_id, !saved)
      setSaved(s => !s)
      showToast(!saved ? 'Saved to My SeRuh 🔖' : 'Removed from saved')
    } catch {
      showToast('Something went wrong. Please try again.')
    }
  }

  const chip = (active) =>
    `rounded-full border px-3.5 py-1.5 text-[0.8rem] font-body transition-all duration-300 ${
      active ? 'border-rose bg-rose text-ivory shadow-sm shadow-rose/25'
             : 'border-linec bg-card text-softink hover:border-rose/60 hover:text-rosedeep'
    }`

  return (
    <section id="generate" className="relative py-24 sm:py-28 px-5 overflow-hidden">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="blob blob-a w-[30vw] h-[30vw] min-w-60 min-h-60 top-[5%] left-[-8%]" style={{ background: 'rgba(169,155,184,0.12)' }} />
        <div className="blob blob-c w-[24vw] h-[24vw] min-w-48 min-h-48 bottom-[0%] right-[-6%]" style={{ background: 'rgba(194,168,120,0.10)' }} />
      </div>

      <div className="relative mx-auto max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
          className="text-center mb-11"
        >
          <p className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-4">✨ Turn Your Feelings Into Words</p>
          <h2 className="font-display text-[clamp(2.1rem,5vw,3rem)] text-charcoal">What are you feeling?</h2>
          <p className="font-body text-softink mt-3">Tell SeRuh what you&rsquo;re feeling. Let it find the words.</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-[1.5rem] bg-card border border-linec p-6 sm:p-9 shadow-xl shadow-charcoal/[0.05]"
        >
          <label htmlFor="ai-feeling" className="sr-only">What are you feeling?</label>
          <textarea
            id="ai-feeling"
            value={feeling}
            onChange={e => setFeeling(e.target.value)}
            rows={3} maxLength={500}
            placeholder="I miss someone, but I know going back isn't right…"
            className="w-full rounded-xl bg-ivory border border-linec px-4.5 py-3.5 font-display text-lg leading-relaxed text-charcoal placeholder:text-faint placeholder:font-body placeholder:text-[0.95rem] focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25 resize-y"
          />

          <div className="mt-5 flex flex-col gap-3.5">
            <div>
              <p className="font-body text-[0.72rem] tracking-[0.16em] uppercase text-faint mb-2">Mood <span className="normal-case tracking-normal">(optional)</span></p>
              <div role="group" aria-label="Mood" className="flex flex-wrap gap-1.5">
                {MOODS.map(m => (
                  <button key={m} onClick={() => setMood(mood === m ? null : m)} aria-pressed={mood === m} className={chip(mood === m)}>{m}</button>
                ))}
              </div>
            </div>
            <div className="grid sm:grid-cols-[1fr_auto] gap-3.5">
              <div>
                <p className="font-body text-[0.72rem] tracking-[0.16em] uppercase text-faint mb-2">Style</p>
                <div role="group" aria-label="Style" className="flex flex-wrap gap-1.5">
                  {STYLES.map(st => (
                    <button key={st} onClick={() => setStyle(st)} aria-pressed={style === st} className={chip(style === st)}>{st}</button>
                  ))}
                </div>
              </div>
              <div>
                <p className="font-body text-[0.72rem] tracking-[0.16em] uppercase text-faint mb-2">Length</p>
                <div role="group" aria-label="Length" className="flex flex-wrap gap-1.5">
                  {LENGTHS.map(l => (
                    <button key={l} onClick={() => setLength(l)} aria-pressed={length === l} className={chip(length === l)}>{l}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={generate}
            disabled={state === 'loading'}
            className="mt-7 w-full inline-flex items-center justify-center gap-2.5 rounded-full bg-charcoal text-ivory px-8 py-4 text-[0.98rem] hover:bg-rosedeep transition-colors duration-300 disabled:opacity-70"
          >
            <Sparkles size={17} aria-hidden="true" className={state === 'loading' ? 'animate-pulse' : ''} />
            {state === 'loading' ? 'Listening…' : '✨ Find My Words'}
          </button>

          {/* result / notices */}
          <div aria-live="polite">
            <AnimatePresence mode="wait">
              {state === 'done' && result && (
                <motion.figure
                  key={result.generation_id}
                  initial={{ opacity: 0, y: 18, filter: 'blur(6px)' }}
                  animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, y: -12, filter: 'blur(6px)' }}
                  transition={{ duration: 0.55, ease: 'easeOut' }}
                  className="mt-8 rounded-2xl bg-ivory border border-gold/35 p-7 sm:p-9 text-center"
                >
                  <blockquote className="font-display text-[clamp(1.35rem,3.5vw,1.8rem)] leading-[1.55] text-charcoal whitespace-pre-line">
                    {result.quote}
                  </blockquote>
                  <figcaption className="font-body text-[0.75rem] tracking-[0.18em] uppercase text-gold mt-5">
                    Generated by SeRuh AI{result.demo ? ' · demo' : ''}
                  </figcaption>
                  <div className="mt-6 flex flex-wrap justify-center gap-2">
                    <button onClick={() => { setLiked(v => !v); if (!liked) showToast('Kept close ❤️') }} aria-pressed={liked}
                      className={`flex items-center gap-1.5 rounded-full border px-4 py-2 text-[0.82rem] transition-colors ${liked ? 'border-rose bg-roseveil text-rosedeep' : 'border-linec text-softink hover:border-rose hover:text-rosedeep'}`}>
                      <Heart size={14} className={liked ? 'fill-rose text-rose' : ''} aria-hidden="true" /> Like
                    </button>
                    <button onClick={saveIt} aria-pressed={saved}
                      className={`flex items-center gap-1.5 rounded-full border px-4 py-2 text-[0.82rem] transition-colors ${saved ? 'border-rose bg-roseveil text-rosedeep' : 'border-linec text-softink hover:border-rose hover:text-rosedeep'}`}>
                      <Bookmark size={14} className={saved ? 'fill-rose text-rose' : ''} aria-hidden="true" /> {saved ? 'Saved' : 'Save to My SeRuh'}
                    </button>
                    <button onClick={() => copyQuote({ quote: result.quote })}
                      className="flex items-center gap-1.5 rounded-full border border-linec px-4 py-2 text-[0.82rem] text-softink hover:border-rose hover:text-rosedeep transition-colors">
                      <Copy size={14} aria-hidden="true" /> Copy
                    </button>
                    <button onClick={() => openShare({ quote: result.quote })}
                      className="flex items-center gap-1.5 rounded-full border border-linec px-4 py-2 text-[0.82rem] text-softink hover:border-rose hover:text-rosedeep transition-colors">
                      <Share2 size={14} aria-hidden="true" /> Share
                    </button>
                    <button onClick={generate}
                      className="flex items-center gap-1.5 rounded-full bg-charcoal text-ivory px-4.5 py-2 text-[0.82rem] hover:bg-rosedeep transition-colors">
                      <Sparkles size={14} aria-hidden="true" /> Generate Another
                    </button>
                  </div>
                  {typeof result.remaining === 'number' && !result.demo && (
                    <p className="font-body text-[0.72rem] text-faint mt-4">{result.remaining} generations left today</p>
                  )}
                </motion.figure>
              )}

              {(state === 'blocked' || state === 'limited') && (
                <motion.div
                  key={state + notice}
                  initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.45 }}
                  className="mt-8 rounded-2xl bg-ivory border border-linec p-7 text-center"
                >
                  <p className="font-display text-[1.15rem] text-charcoal leading-relaxed">{notice}</p>
                  <div className="mt-5 flex justify-center gap-2.5 flex-wrap">
                    {state === 'blocked' && (
                      <button onClick={generate} className="rounded-full border border-linec px-5 py-2.5 text-[0.85rem] text-softink hover:border-rose hover:text-rosedeep transition-colors">
                        Try Again
                      </button>
                    )}
                    {state === 'limited' && auth?.available && !auth?.user && (
                      <button onClick={auth.openAuth} className="rounded-full bg-charcoal text-ivory px-5 py-2.5 text-[0.85rem] hover:bg-rosedeep transition-colors">
                        Create a free account
                      </button>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {BACKEND_MODE === 'local' && (
            <p className="font-body text-[0.72rem] text-faint text-center mt-5">
              Demo mode — SeRuh AI fully awakens once the backend is connected.
            </p>
          )}
        </motion.div>
      </div>
    </section>
  )
}
