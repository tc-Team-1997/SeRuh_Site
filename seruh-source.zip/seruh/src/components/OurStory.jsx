import { motion } from 'framer-motion'

export default function OurStory() {
  return (
    <section id="story" className="relative py-24 sm:py-32 px-5 overflow-hidden">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="blob blob-a w-[34vw] h-[34vw] min-w-64 min-h-64 top-[10%] right-[-10%]" style={{ background: 'rgba(183,110,121,0.10)' }} />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="relative mx-auto max-w-2xl text-center"
      >
        <p className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-4">Our Story</p>
        <h2 className="font-display text-[clamp(2.1rem,5vw,3rem)] text-charcoal mb-10">A place for what we carry</h2>

        <div className="font-body text-softink text-[1.02rem] leading-[1.9] space-y-6 text-left sm:text-center">
          <p>
            SeRuh began with a simple thought — there are feelings we carry quietly, memories we
            revisit when no one is looking, and words that arrive only when we&rsquo;re finally ready
            to hear them.
          </p>
          <p>
            This is a home for those moments. For the thoughts that circle at midnight, the
            memories that live in old songs, the things we almost said, and the small, quiet
            joys that never make it into conversation. Here, they are written down — gently,
            without judgement — so that someone else, somewhere, can find them and feel a
            little less alone.
          </p>
        </div>

        <p className="font-display italic text-[1.4rem] sm:text-[1.6rem] text-charcoal mt-12 leading-relaxed">
          &ldquo;Some feelings don&rsquo;t need an explanation.<br className="hidden sm:block" />
          They just need a place to exist.&rdquo;
        </p>
        <div aria-hidden="true" className="mx-auto mt-8 h-px w-16 bg-gold/60" />
      </motion.div>
    </section>
  )
}
