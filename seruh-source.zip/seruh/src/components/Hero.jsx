import { motion } from 'framer-motion'

const fade = {
  hidden: { opacity: 0, y: 22, filter: 'blur(6px)' },
  show: (i) => ({
    opacity: 1, y: 0, filter: 'blur(0px)',
    transition: { delay: 0.25 + i * 0.18, duration: 0.9, ease: [0.22, 1, 0.36, 1] },
  }),
}

export default function Hero() {
  return (
    <section id="home" className="grain relative overflow-hidden min-h-[92svh] flex items-center justify-center">
      {/* atmosphere */}
      <div aria-hidden="true" className="absolute inset-0">
        <div className="blob blob-a w-[46vw] h-[46vw] min-w-72 min-h-72 top-[-12%] left-[-8%]" style={{ background: 'rgba(183,110,121,0.16)' }} />
        <div className="blob blob-b w-[40vw] h-[40vw] min-w-64 min-h-64 bottom-[-16%] right-[-6%]" style={{ background: 'rgba(169,155,184,0.18)' }} />
        <div className="blob blob-c w-[26vw] h-[26vw] min-w-48 min-h-48 top-[30%] right-[22%]" style={{ background: 'rgba(194,168,120,0.13)' }} />
      </div>

      <div className="relative z-10 text-center px-6 max-w-3xl mx-auto pt-24 pb-16">
        <motion.p
          variants={fade} initial="hidden" animate="show" custom={0}
          className="font-body text-[11px] sm:text-xs tracking-[0.35em] uppercase text-gold mb-7"
        >
          A quiet place for loud hearts
        </motion.p>

        <motion.h1
          variants={fade} initial="hidden" animate="show" custom={1}
          className="font-display font-medium text-charcoal leading-none text-[clamp(4.2rem,14vw,8.5rem)] tracking-tight"
        >
          Se<span className="text-rose">Ruh</span>
        </motion.h1>

        <motion.p
          variants={fade} initial="hidden" animate="show" custom={2}
          className="font-display italic text-[clamp(1.35rem,3.4vw,1.9rem)] text-charcoal/85 mt-5"
        >
          Where Feelings Find Words.
        </motion.p>

        <motion.p
          variants={fade} initial="hidden" animate="show" custom={3}
          className="font-body text-softink text-[0.98rem] sm:text-base mt-5 max-w-md mx-auto leading-relaxed"
        >
          For the thoughts we feel, but don&rsquo;t always know how to say.
        </motion.p>

        <motion.div
          variants={fade} initial="hidden" animate="show" custom={4}
          className="mt-11 flex flex-col sm:flex-row items-center justify-center gap-3.5"
        >
          <a
            href="#explore"
            className="w-full sm:w-auto rounded-full bg-charcoal text-ivory px-8 py-3.5 text-[0.95rem] hover:bg-rosedeep transition-colors duration-300"
          >
            Explore Feelings
          </a>
          <a
            href="#write"
            className="w-full sm:w-auto rounded-full border border-charcoal/25 text-charcoal px-8 py-3.5 text-[0.95rem] hover:border-rose hover:text-rosedeep transition-colors duration-300"
          >
            Write Your Feeling
          </a>
        </motion.div>
      </div>

      {/* soft bottom fade into the page */}
      <div aria-hidden="true" className="absolute bottom-0 inset-x-0 h-28 bg-gradient-to-b from-transparent to-ivory" />
    </section>
  )
}
