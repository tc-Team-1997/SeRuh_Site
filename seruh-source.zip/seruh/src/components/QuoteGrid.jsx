import { AnimatePresence, motion } from 'framer-motion'
import QuoteCard from './QuoteCard'

export default function QuoteGrid({ quotes, filterKey }) {
  if (quotes.length === 0) {
    return (
      <motion.div
        key="empty"
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center py-20 px-6"
      >
        <p className="font-display text-3xl text-charcoal mb-3">We couldn&rsquo;t find that feeling…</p>
        <p className="font-body text-softink max-w-md mx-auto mb-8">
          Maybe the words you&rsquo;re looking for haven&rsquo;t been written yet.
        </p>
        <a
          href="#write"
          className="inline-block rounded-full bg-charcoal text-ivory px-7 py-3 text-[0.92rem] hover:bg-rosedeep transition-colors duration-300"
        >
          Write Your Feeling
        </a>
      </motion.div>
    )
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={filterKey}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="columns-1 sm:columns-2 lg:columns-3 gap-5 mt-14"
      >
        {quotes.map((q, i) => (
          <QuoteCard key={q.id} quote={q} index={i} />
        ))}
      </motion.div>
    </AnimatePresence>
  )
}
