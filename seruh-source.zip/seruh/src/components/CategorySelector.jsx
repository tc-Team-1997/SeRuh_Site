import { iconForCategory } from '../data/quotes'
import { useData } from '../context/DataContext'

export default function CategorySelector({ selected, onSelect }) {
  const { categories } = useData()

  return (
    <div id="categories" className="mt-12">
      <h3 className="text-center font-display text-2xl text-charcoal mb-7">Explore by Feeling</h3>
      <div role="group" aria-label="Filter quotes by feeling" className="flex flex-wrap justify-center gap-2 sm:gap-2.5 max-w-3xl mx-auto">
        <Chip active={selected === null} onClick={() => onSelect(null)} label="All Feelings" />
        {categories.map(name => (
          <Chip
            key={name}
            active={selected === name}
            onClick={() => onSelect(selected === name ? null : name)}
            label={name}
            Icon={iconForCategory(name)}
          />
        ))}
      </div>
    </div>
  )
}

function Chip({ active, onClick, label, Icon }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`flex items-center gap-1.5 rounded-full border px-4 py-2 text-[0.83rem] transition-all duration-300 ${
        active
          ? 'border-rose bg-rose text-ivory shadow-md shadow-rose/25'
          : 'border-linec bg-card text-softink hover:border-rose/60 hover:text-rosedeep'
      }`}
    >
      {Icon && <Icon size={14} aria-hidden="true" className={active ? 'text-ivory' : 'text-rose'} />}
      {label}
    </button>
  )
}
