import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { api } from '../services/api'
import SearchBar from './SearchBar'
import CategorySelector from './CategorySelector'
import QuoteGrid from './QuoteGrid'
import { GridSkeleton } from './Skeleton'

const PAGE_SIZE = 12

export default function ExploreSection() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState(null)
  const [items, setItems] = useState([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [failed, setFailed] = useState(false)
  const [retryTick, setRetryTick] = useState(0)
  const reqId = useRef(0)

  // fetch on filter/search change (debounced for typing)
  useEffect(() => {
    const id = ++reqId.current
    setLoading(true)
    setFailed(false)
    const t = setTimeout(() => {
      if (query.trim()) api.track?.('search', null, null, { len: query.trim().length })
      if (category) api.track?.('category_view', 'category', category)
      api.getQuotes({ page: 0, pageSize: PAGE_SIZE, category, search: query })
        .then(res => {
          if (reqId.current !== id) return
          setItems(res.items); setTotal(res.total); setPage(0); setLoading(false)
        })
        .catch(() => {
          if (reqId.current !== id) return
          setFailed(true); setLoading(false)
        })
    }, query ? 280 : 0)
    return () => clearTimeout(t)
  }, [query, category, retryTick])

  const loadMore = async () => {
    setLoadingMore(true)
    try {
      const res = await api.getQuotes({ page: page + 1, pageSize: PAGE_SIZE, category, search: query })
      setItems(prev => [...prev, ...res.items])
      setTotal(res.total)
      setPage(p => p + 1)
    } catch { /* quiet — button stays for retry */ }
    setLoadingMore(false)
  }

  return (
    <section id="explore" className="relative py-24 sm:py-28 px-5 bg-cream/60">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
          className="text-center mb-10"
        >
          <p className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-4">Explore</p>
          <h2 className="font-display text-[clamp(2.1rem,5vw,3rem)] text-charcoal">Find the Words</h2>
          <p className="font-body text-softink mt-3 max-w-lg mx-auto">
            Wander through feelings, or search for the one you&rsquo;re carrying today.
          </p>
        </motion.div>

        <SearchBar value={query} onChange={setQuery} />
        <CategorySelector selected={category} onSelect={setCategory} />

        {loading ? (
          <GridSkeleton />
        ) : failed ? (
          <div className="text-center py-20">
            <p className="font-display text-2xl text-charcoal mb-3">Something went wrong.</p>
            <p className="font-body text-softink mb-6">Please try again in a moment.</p>
            <button
              onClick={() => setRetryTick(t => t + 1)}
              className="rounded-full border border-linec px-6 py-2.5 text-[0.88rem] text-softink hover:border-rose hover:text-rosedeep transition-colors"
            >
              Retry
            </button>
          </div>
        ) : (
          <>
            <QuoteGrid quotes={items} filterKey={`${category ?? 'all'}·${query.trim().toLowerCase()}`} />
            {items.length > 0 && items.length < total && (
              <div className="text-center mt-4">
                <button
                  onClick={loadMore}
                  disabled={loadingMore}
                  className="rounded-full border border-linec bg-card px-7 py-3 text-[0.88rem] text-softink hover:border-rose hover:text-rosedeep transition-colors disabled:opacity-60"
                >
                  {loadingMore ? 'Gathering more…' : `More feelings (${total - items.length})`}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  )
}
