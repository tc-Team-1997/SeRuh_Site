const LINKS = [
  { label: 'Explore', href: '#explore' },
  { label: 'Categories', href: '#categories' },
  { label: 'Write Your Feeling', href: '#write' },
  { label: 'Our Story', href: '#story' },
]

export default function Footer() {
  return (
    <footer className="bg-charcoal text-ivory/80">
      <div className="mx-auto max-w-6xl px-6 py-16 text-center">
        <p className="font-display text-3xl text-ivory">
          Se<span className="text-rose">Ruh</span>
        </p>
        <p className="font-display italic text-ivory/70 mt-2">Where Feelings Find Words.</p>

        <nav aria-label="Footer" className="mt-9 flex flex-wrap justify-center gap-x-7 gap-y-3">
          {LINKS.map(l => (
            <a key={l.href} href={l.href} className="font-body text-[0.88rem] text-ivory/60 hover:text-ivory transition-colors">
              {l.label}
            </a>
          ))}
        </nav>

        <div aria-hidden="true" className="mx-auto mt-10 mb-8 h-px w-20 bg-ivory/15" />

        <p className="font-display italic text-ivory/50 text-[0.95rem]">
          For everything that words couldn&rsquo;t say.
        </p>
        <p className="font-body text-[0.75rem] text-ivory/35 mt-4 tracking-wide">© 2026 SeRuh</p>
      </div>
    </footer>
  )
}
