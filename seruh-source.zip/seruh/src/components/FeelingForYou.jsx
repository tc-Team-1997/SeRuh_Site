import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { api } from '../services/api'
import { useAuth } from '../context/AuthContext'
import QuoteCard from './QuoteCard'

export default function FeelingForYou() {
  const { user, authVersion } = useAuth()
  const [items, setItems] = useState([])

  useEffect(() => {
    if (!user) { setItems([]); return }
    let alive = true
    api.getRecommendedQuotes(3)
      .then(list => { if (alive) setItems(list ?? []) })
      .catch(() => {})
    return () => { alive = false }
  }, [user, authVersion])

  if (!user || items.length === 0) return null

  return (
    <section aria-label="A feeling for you" className="relative pt-4 pb-16 px-5">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }} transition={{ duration: 0.7 }}
          className="text-center mb-9"
        >
          <p className="font-display italic text-lg text-softink">Welcome back, {user.name?.split(' ')[0] || 'you'} ❤️</p>
          <h2 className="font-display text-[clamp(1.7rem,4vw,2.3rem)] text-charcoal mt-1.5">A Feeling For You</h2>
        </motion.div>
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-5">
          {items.map((q, i) => <QuoteCard key={q.id} quote={q} index={i} />)}
        </div>
      </div>
    </section>
  )
}
