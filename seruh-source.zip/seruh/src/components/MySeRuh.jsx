import { useCallback, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Bookmark, Copy, Share2, Trash2, Sparkles, User, Heart, Clock, Settings as SettingsIcon, Inbox } from 'lucide-react'
import { api, BACKEND_MODE } from '../services/api'
import { auth } from '../services/auth'
import { useAuth } from '../context/AuthContext'
import { useUi } from '../context/UiContext'
import { RowSkeleton } from './Skeleton'

const TABS = [
  { key: 'saved', label: 'My Saved Feelings', icon: Bookmark },
  { key: 'generated', label: 'My Generated Quotes', icon: Sparkles },
  { key: 'submissions', label: 'My Submissions', icon: Inbox },
  { key: 'likes', label: 'My Likes', icon: Heart },
  { key: 'activity', label: 'My Activity', icon: Clock },
  { key: 'settings', label: 'Settings', icon: SettingsIcon },
]

function fmtDate(iso) {
  if (!iso) return ''
  try { return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) } catch { return '' }
}

function tabFromHash() {
  const m = window.location.hash.match(/^#\/me\/?([a-z]*)/)
  return TABS.some(t => t.key === m?.[1]) ? m[1] : 'saved'
}

export default function MySeRuh() {
  const { user, available, openAuth } = useAuth()
  const [tab, setTab] = useState(tabFromHash())

  useEffect(() => {
    const onHash = () => setTab(tabFromHash())
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  const guestMode = !user

  return (
    <div className="min-h-svh bg-ivory pt-24 pb-24 px-5">
      <div className="mx-auto max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-center mb-10">
          <p className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-3">My SeRuh</p>
          <h1 className="font-display text-[clamp(2rem,5vw,2.8rem)] text-charcoal">
            {user ? <>Hello, {user.name?.split(' ')[0] || 'you'} ❤️</> : 'Your quiet corner'}
          </h1>
          {guestMode && (
            <p className="font-body text-softink text-[0.92rem] mt-3 max-w-md mx-auto">
              {available
                ? <>You&rsquo;re browsing as a guest — your feelings live in this browser only. <button onClick={openAuth} className="text-rosedeep underline underline-offset-2">Create a free account</button> to keep them everywhere.</>
                : 'You’re browsing as a guest — your feelings live in this browser.'}
            </p>
          )}
        </motion.div>

        {/* tabs */}
        <div role="tablist" aria-label="My SeRuh" className="flex flex-wrap justify-center gap-2 mb-10">
          {TABS.filter(t => t.key !== 'settings' || user).map(({ key, label, icon: Icon }) => (
            <a key={key} role="tab" aria-selected={tab === key} href={`#/me/${key}`}
              className={`flex items-center gap-1.5 rounded-full border px-4 py-2 text-[0.82rem] font-body transition-colors ${
                tab === key ? 'border-rose bg-rose text-ivory' : 'border-linec bg-card text-softink hover:border-rose/60 hover:text-rosedeep'
              }`}>
              <Icon size={13} aria-hidden="true" /> {label}
            </a>
          ))}
        </div>

        {tab === 'saved' && <SavedTab />}
        {tab === 'generated' && <GeneratedTab />}
        {tab === 'submissions' && <SubmissionsTab guest={guestMode} />}
        {tab === 'likes' && <LikesTab />}
        {tab === 'activity' && <ActivityTab />}
        {tab === 'settings' && user && <SettingsTab />}

        <div className="text-center mt-14">
          <a href="#home" className="font-body text-[0.85rem] text-faint hover:text-rosedeep transition-colors">← Back to SeRuh</a>
        </div>
      </div>
    </div>
  )
}

/* ── shared bits ─────────────────────────────────────────────── */

function Empty({ title, sub, cta, href }) {
  return (
    <div className="text-center py-16">
      <p className="font-display text-2xl text-charcoal mb-2.5">{title}</p>
      {sub && <p className="font-body text-softink mb-7">{sub}</p>}
      {cta && (
        <a href={href} className="inline-block rounded-full bg-charcoal text-ivory px-7 py-3 text-[0.9rem] hover:bg-rosedeep transition-colors">{cta}</a>
      )}
    </div>
  )
}

function RowActions({ onCopy, onShare, onRemove, removeLabel = 'Remove' }) {
  return (
    <div className="flex sm:flex-col gap-1 shrink-0">
      {onCopy && <button onClick={onCopy} aria-label="Copy" className="p-2.5 rounded-full text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors"><Copy size={16} aria-hidden="true" /></button>}
      {onShare && <button onClick={onShare} aria-label="Share" className="p-2.5 rounded-full text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors"><Share2 size={16} aria-hidden="true" /></button>}
      {onRemove && <button onClick={onRemove} aria-label={removeLabel} title={removeLabel} className="p-2.5 rounded-full text-softink hover:text-ivory hover:bg-rosedeep transition-colors"><Trash2 size={16} aria-hidden="true" /></button>}
    </div>
  )
}

/* ── tabs ────────────────────────────────────────────────────── */

function SavedTab() {
  const { copyQuote, openShare } = useUi()
  const { authVersion } = useAuth()
  const [quotes, setQuotes] = useState(null)
  const [gens, setGens] = useState([])
  const [tick, setTick] = useState(0)

  useEffect(() => {
    let alive = true
    Promise.all([api.getSavedQuotes().catch(() => []), api.getMyGenerations().catch(() => [])])
      .then(([q, g]) => { if (alive) { setQuotes(q); setGens((g ?? []).filter(x => x.saved)) } })
    return () => { alive = false }
  }, [authVersion, tick])

  if (!quotes) return <RowSkeleton rows={3} />
  const all = [
    ...gens.map(g => ({ kind: 'ai', id: g.id, quote: g.generated_text, mood: g.mood, at: g.created_at })),
    ...quotes.map(q => ({ kind: 'quote', ...q, at: q.saved_at })),
  ].sort((a, b) => ((a.at ?? '') < (b.at ?? '') ? 1 : -1))

  if (all.length === 0) {
    return <Empty title="Your little collection is still waiting to begin." sub="When a feeling speaks to you, keep it close." cta="Explore Feelings" href="#explore" />
  }

  return (
    <div className="flex flex-col gap-4">
      {all.map(item => (
        <article key={`${item.kind}-${item.id}`} className="rounded-2xl bg-card border border-linec p-6 flex flex-col sm:flex-row gap-4">
          <div className="flex-1 min-w-0">
            <blockquote className="font-display text-[1.1rem] leading-[1.55] text-charcoal whitespace-pre-line">{item.quote}</blockquote>
            <p className="font-body text-[0.75rem] text-faint mt-2.5">
              {item.kind === 'ai'
                ? <span className="text-gold">✨ Generated by SeRuh AI</span>
                : <span className="text-rose">#{(item.category ?? '').replace(/\s+/g, '')}</span>}
              {item.at && <> · saved {fmtDate(item.at)}</>}
            </p>
          </div>
          <RowActions
            onCopy={() => copyQuote({ quote: item.quote, id: item.kind === 'quote' ? item.id : undefined })}
            onShare={() => openShare({ quote: item.quote, id: item.kind === 'quote' ? item.id : undefined })}
            onRemove={async () => {
              if (item.kind === 'ai') await api.setGenerationSaved(item.id, false).catch(() => {})
              else await api.toggleQuoteSave(item.id).catch(() => {})
              setTick(t => t + 1)
            }}
          />
        </article>
      ))}
    </div>
  )
}

function GeneratedTab() {
  const { copyQuote, openShare, showToast } = useUi()
  const { authVersion } = useAuth()
  const [items, setItems] = useState(null)
  const [tick, setTick] = useState(0)

  useEffect(() => {
    let alive = true
    api.getMyGenerations().then(g => { if (alive) setItems(g ?? []) }).catch(() => setItems([]))
    return () => { alive = false }
  }, [authVersion, tick])

  if (!items) return <RowSkeleton rows={3} />
  if (items.length === 0) {
    return <Empty title="Your words haven't been transformed yet." sub="Tell SeRuh what you're feeling — it will find the words." cta="✨ Find My Words" href="#generate" />
  }

  return (
    <div className="flex flex-col gap-4">
      {items.map(g => (
        <article key={g.id} className="rounded-2xl bg-card border border-linec p-6">
          <blockquote className="font-display text-[1.1rem] leading-[1.55] text-charcoal whitespace-pre-line">{g.generated_text}</blockquote>
          <p className="font-body text-[0.78rem] text-faint mt-3 italic">You felt: “{g.input_text}”</p>
          <p className="font-body text-[0.72rem] text-faint mt-1.5">
            {[g.mood, g.style, g.length].filter(Boolean).join(' · ')}{g.created_at ? ` · ${fmtDate(g.created_at)}` : ''}
          </p>
          <div className="mt-4 pt-3.5 border-t border-linec/70 flex flex-wrap gap-1">
            <button onClick={async () => { await api.setGenerationSaved(g.id, !g.saved).catch(() => {}); setTick(t => t + 1); showToast(!g.saved ? 'Saved to My SeRuh 🔖' : 'Removed from saved') }}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] transition-colors ${g.saved ? 'text-rosedeep bg-roseveil' : 'text-softink hover:text-rosedeep hover:bg-roseveil/60'}`}>
              <Bookmark size={14} className={g.saved ? 'fill-rose text-rose' : ''} aria-hidden="true" /> {g.saved ? 'Saved' : 'Save'}
            </button>
            <button onClick={() => copyQuote({ quote: g.generated_text })} className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors">
              <Copy size={14} aria-hidden="true" /> Copy
            </button>
            <button onClick={() => openShare({ quote: g.generated_text })} className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors">
              <Share2 size={14} aria-hidden="true" /> Share
            </button>
            <a href="#generate" className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors">
              <Sparkles size={14} aria-hidden="true" /> Generate Again
            </a>
            <button onClick={async () => { await api.deleteGeneration(g.id).catch(() => {}); setTick(t => t + 1) }}
              className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-ivory hover:bg-rosedeep transition-colors">
              <Trash2 size={14} aria-hidden="true" /> Delete
            </button>
          </div>
        </article>
      ))}
    </div>
  )
}

function SubmissionsTab({ guest }) {
  const { authVersion } = useAuth()
  const [items, setItems] = useState(null)

  useEffect(() => {
    let alive = true
    api.getMySubmissions().then(s => { if (alive) setItems(s ?? []) }).catch(() => setItems([]))
    return () => { alive = false }
  }, [authVersion])

  if (!items) return <RowSkeleton rows={3} />
  if (items.length === 0) {
    return <Empty
      title="Nothing here yet."
      sub={guest && BACKEND_MODE === 'local' ? 'Submissions appear here once the backend is connected.' : 'When you share a feeling, you can follow it here.'}
      cta="Write Your Feeling" href="#write" />
  }

  const pill = (s) => ({
    PENDING: 'text-amber-700 bg-amber-50 border-amber-200',
    APPROVED: 'text-emerald-700 bg-emerald-50 border-emerald-200',
    REJECTED: 'text-rosedeep bg-roseveil border-rose/30',
    ARCHIVED: 'text-faint bg-cream border-linec',
  }[s] ?? 'text-softink bg-cream border-linec')

  return (
    <div className="flex flex-col gap-4">
      {items.map(f => (
        <article key={f.id} className="rounded-2xl bg-card border border-linec p-6">
          <blockquote className="font-display text-[1.05rem] leading-[1.55] text-charcoal whitespace-pre-line">“{f.content}”</blockquote>
          <p className="font-body text-[0.75rem] text-faint mt-3">
            <span className="text-rose">{f.category}</span> · {f.mood}{f.is_anonymous ? ' · 🕊️ anonymous' : ''} · {fmtDate(f.created_at)}
            {' · '}<span className={`inline-block rounded-full border px-2 py-0.5 text-[0.68rem] ${pill(f.status)}`}>{f.status}</span>
          </p>
        </article>
      ))}
    </div>
  )
}

function LikesTab() {
  const { copyQuote, openShare } = useUi()
  const { authVersion } = useAuth()
  const [items, setItems] = useState(null)

  useEffect(() => {
    let alive = true
    api.getMyLikedQuotes().then(l => { if (alive) setItems(l ?? []) }).catch(() => setItems([]))
    return () => { alive = false }
  }, [authVersion])

  if (!items) return <RowSkeleton rows={3} />
  if (items.length === 0) return <Empty title="Nothing here yet. Start exploring." cta="Explore Feelings" href="#explore" />

  return (
    <div className="flex flex-col gap-4">
      {items.map(q => (
        <article key={q.id} className="rounded-2xl bg-card border border-linec p-6 flex flex-col sm:flex-row gap-4">
          <div className="flex-1 min-w-0">
            <blockquote className="font-display text-[1.05rem] leading-[1.55] text-charcoal whitespace-pre-line">{q.quote}</blockquote>
            <p className="font-body text-[0.75rem] text-faint mt-2.5"><span className="text-rose">#{(q.category ?? '').replace(/\s+/g, '')}</span> · ❤️ {q.like_count}</p>
          </div>
          <RowActions onCopy={() => copyQuote(q)} onShare={() => openShare(q)} />
        </article>
      ))}
    </div>
  )
}

function ActivityTab() {
  const { authVersion } = useAuth()
  const [items, setItems] = useState(null)

  useEffect(() => {
    let alive = true
    api.getMyActivityFeed().then(a => { if (alive) setItems(a ?? []) }).catch(() => setItems([]))
    return () => { alive = false }
  }, [authVersion])

  if (!items) return <RowSkeleton rows={4} />
  if (items.length === 0) return <Empty title="Nothing here yet. Start exploring." cta="Explore Feelings" href="#explore" />

  return (
    <div className="relative">
      <div aria-hidden="true" className="absolute left-[7px] top-2 bottom-2 w-px bg-linec" />
      <div className="flex flex-col gap-5">
        {items.map((a, i) => (
          <div key={i} className="relative pl-8">
            <span aria-hidden="true" className="absolute left-0.5 top-2 h-2.5 w-2.5 rounded-full bg-rose/70" />
            <p className="font-body text-[0.88rem] text-charcoal">
              You <b>{a.label}</b>{a.created_at ? <span className="text-faint"> · {fmtDate(a.created_at)}</span> : null}
            </p>
            {a.detail && <p className="font-display text-[0.95rem] text-softink italic mt-0.5 line-clamp-1">“{a.detail}”</p>}
          </div>
        ))}
      </div>
    </div>
  )
}

/* ── settings ────────────────────────────────────────────────── */

const PREF_MOODS = ['Romantic','Peaceful','Hopeful','Nostalgic','Emotional','Thoughtful','Happy','Sad']
const PREF_STYLES = ['Short & Deep','Poetic','Romantic','Minimal','Emotional','Philosophical','Hopeful','Midnight']

function SettingsTab() {
  const { user, refreshProfile, signOut } = useAuth()
  const { showToast } = useUi()
  const [prefs, setPrefs] = useState(null)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    auth.getPreferences().then(p => setPrefs(p ?? {})).catch(() => setPrefs({}))
  }, [])

  const inputCls = 'w-full rounded-xl bg-card border border-linec px-4 py-2.5 text-[0.92rem] text-charcoal font-body focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25'
  const labelCls = 'block font-body text-[0.8rem] font-medium text-softink mb-1.5'
  const btnCls = 'rounded-full border border-linec px-5 py-2.5 text-[0.85rem] text-softink hover:border-rose hover:text-rosedeep transition-colors disabled:opacity-50'

  const run = async (fn, msg) => {
    setBusy(true)
    try { await fn(); showToast(msg) }
    catch (e) { showToast(String(e?.message || '').includes('email') ? 'Check the new email for a confirmation link.' : 'Something went wrong. Please try again.') }
    finally { setBusy(false) }
  }

  if (!prefs) return <RowSkeleton rows={4} />

  return (
    <div className="flex flex-col gap-6 max-w-xl mx-auto">
      <section className="rounded-2xl bg-card border border-linec p-6">
        <h2 className="font-display text-xl text-charcoal mb-4">Profile</h2>
        <form className="flex flex-col gap-4" onSubmit={async e => {
          e.preventDefault()
          const d = Object.fromEntries(new FormData(e.target).entries())
          await run(async () => {
            if (d.name.trim() && d.name.trim() !== user.name) await auth.updateName(d.name)
            if (d.email.trim() && d.email.trim() !== user.email) await auth.updateEmail(d.email.trim())
            await refreshProfile()
          }, 'Profile updated')
        }}>
          <div><label htmlFor="st-name" className={labelCls}>Name</label>
            <input id="st-name" name="name" defaultValue={user.name} maxLength={80} className={inputCls} /></div>
          <div><label htmlFor="st-email" className={labelCls}>Email</label>
            <input id="st-email" name="email" type="email" defaultValue={user.email} className={inputCls} />
            <p className="font-body text-[0.72rem] text-faint mt-1.5">Changing email sends a confirmation link to the new address.</p></div>
          <button type="submit" disabled={busy} className={btnCls + ' self-start'}>Save profile</button>
        </form>
      </section>

      <section className="rounded-2xl bg-card border border-linec p-6">
        <h2 className="font-display text-xl text-charcoal mb-4">Password</h2>
        <form className="flex flex-col gap-4" onSubmit={async e => {
          e.preventDefault()
          const d = Object.fromEntries(new FormData(e.target).entries())
          if ((d.password || '').length < 8) { showToast('Password needs at least 8 characters.'); return }
          await run(() => auth.updatePassword(d.password), 'Password changed')
          e.target.reset()
        }}>
          <div><label htmlFor="st-pass" className={labelCls}>New password</label>
            <input id="st-pass" name="password" type="password" minLength={8} required className={inputCls} autoComplete="new-password" /></div>
          <button type="submit" disabled={busy} className={btnCls + ' self-start'}>Change password</button>
        </form>
      </section>

      <section className="rounded-2xl bg-card border border-linec p-6">
        <h2 className="font-display text-xl text-charcoal mb-1.5">Preferences</h2>
        <p className="font-body text-[0.8rem] text-faint mb-4">Used only to make SeRuh feel more like yours.</p>
        <div className="flex flex-col gap-4">
          <div>
            <p className={labelCls}>Preferred mood</p>
            <div className="flex flex-wrap gap-1.5">
              {PREF_MOODS.map(m => (
                <button key={m} onClick={() => setPrefs(p => ({ ...p, preferred_mood: p.preferred_mood === m ? null : m }))}
                  aria-pressed={prefs.preferred_mood === m}
                  className={`rounded-full border px-3.5 py-1.5 text-[0.8rem] font-body transition-colors ${prefs.preferred_mood === m ? 'border-rose bg-rose text-ivory' : 'border-linec text-softink hover:border-rose/60'}`}>
                  {m}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className={labelCls}>Preferred quote style</p>
            <div className="flex flex-wrap gap-1.5">
              {PREF_STYLES.map(s => (
                <button key={s} onClick={() => setPrefs(p => ({ ...p, preferred_style: p.preferred_style === s ? null : s }))}
                  aria-pressed={prefs.preferred_style === s}
                  className={`rounded-full border px-3.5 py-1.5 text-[0.8rem] font-body transition-colors ${prefs.preferred_style === s ? 'border-rose bg-rose text-ivory' : 'border-linec text-softink hover:border-rose/60'}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-3 font-body text-[0.88rem] text-softink cursor-pointer">
            <input type="checkbox" className="accent-rose w-4 h-4"
              checked={!!prefs.notifications?.email_updates}
              onChange={e => setPrefs(p => ({ ...p, notifications: { ...(p.notifications ?? {}), email_updates: e.target.checked } }))} />
            Email me occasional SeRuh updates
          </label>
          <button disabled={busy} onClick={() => run(() => auth.savePreferences({
            preferred_mood: prefs.preferred_mood ?? null,
            preferred_style: prefs.preferred_style ?? null,
            notifications: prefs.notifications ?? {},
          }), 'Preferences saved')} className={btnCls + ' self-start'}>
            Save preferences
          </button>
        </div>
      </section>

      <section className="rounded-2xl border border-rose/30 bg-roseveil/40 p-6">
        <h2 className="font-display text-xl text-charcoal mb-1.5">Delete account</h2>
        <p className="font-body text-[0.85rem] text-softink mb-4">
          This permanently removes your account, saved quotes, likes and generated words. Feelings already on the public wall stay, fully anonymized. This cannot be undone.
        </p>
        {!confirmDelete ? (
          <button onClick={() => setConfirmDelete(true)} className="rounded-full border border-rose/50 text-rosedeep px-5 py-2.5 text-[0.85rem] hover:bg-roseveil transition-colors">
            Delete my account
          </button>
        ) : (
          <div className="flex gap-2.5 flex-wrap">
            <button onClick={() => setConfirmDelete(false)} className={btnCls}>Keep my account</button>
            <button disabled={busy} onClick={async () => {
              setBusy(true)
              try { await auth.deleteAccount(); showToast('Your account has been deleted. Take care. 🕊️'); window.location.hash = '#home' }
              catch { showToast('Something went wrong. Please try again.'); setBusy(false) }
            }} className="rounded-full bg-rosedeep text-ivory px-5 py-2.5 text-[0.85rem] hover:brightness-110 transition-all disabled:opacity-60">
              Yes, delete forever
            </button>
          </div>
        )}
      </section>

      <button onClick={signOut} className="font-body text-[0.85rem] text-faint hover:text-rosedeep transition-colors self-center flex items-center gap-2">
        <User size={14} aria-hidden="true" /> Logout
      </button>
    </div>
  )
}
