export function QuoteCardSkeleton() {
  return (
    <div className="mb-5 break-inside-avoid rounded-2xl bg-card border border-linec p-7 sm:p-8 animate-pulse" aria-hidden="true">
      <div className="h-4 rounded bg-cream w-full mb-3" />
      <div className="h-4 rounded bg-cream w-5/6 mb-3" />
      <div className="h-4 rounded bg-cream w-2/3 mb-6" />
      <div className="flex gap-3 mb-5">
        <div className="h-3 rounded bg-cream w-16" />
        <div className="h-3 rounded bg-cream w-12" />
      </div>
      <div className="pt-4 border-t border-linec/70 flex gap-3">
        <div className="h-6 rounded-full bg-cream w-16" />
        <div className="h-6 rounded-full bg-cream w-16" />
        <div className="h-6 rounded-full bg-cream w-16" />
      </div>
    </div>
  )
}

export function GridSkeleton({ count = 6 }) {
  return (
    <div className="columns-1 sm:columns-2 lg:columns-3 gap-5 mt-14" role="status" aria-label="Loading quotes">
      {Array.from({ length: count }).map((_, i) => <QuoteCardSkeleton key={i} />)}
      <span className="sr-only">Loading…</span>
    </div>
  )
}

export function BigQuoteSkeleton() {
  return (
    <div className="animate-pulse py-6" aria-hidden="true">
      <div className="h-6 rounded bg-cream w-4/5 mx-auto mb-4" />
      <div className="h-6 rounded bg-cream w-3/5 mx-auto mb-4" />
      <div className="h-6 rounded bg-cream w-2/5 mx-auto" />
    </div>
  )
}

export function RowSkeleton({ rows = 5 }) {
  return (
    <div className="animate-pulse space-y-3" role="status" aria-label="Loading">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-14 rounded-xl bg-cream" />
      ))}
      <span className="sr-only">Loading…</span>
    </div>
  )
}
