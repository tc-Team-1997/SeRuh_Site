import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Sparkles } from 'lucide-react'
import { api } from '../services/api'
import { useUi } from '../context/UiContext'

export default function RandomQuote() {
  const [quote, setQuote] = useState(null)
  const { showToast } = useUi()

  const give = async () => {
    try {
      api.track?.('random_quote')
      const next = await api.getRandomQuote(quote?.id ?? null)
      setQuote(next)
    } catch {
      showToast('Something went wrong. Please try again.')
    }
  }

  return (
    <section id="random" aria-label="A random feeling" className="relative py-24 px-5 overflow-hidden">
      {/* faint atmosphere */}
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="blob blob-b w-96 h-96 left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 opacity-70" style={{ background: 'rgba(169,155,184,0.13)' }} />
      </div>

      <div className="relative mx-auto max-w-2xl text-center">
        <motion.p
          initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
          className="font-display italic text-xl text-softink mb-8"
        >
          Sometimes you don&rsquo;t know what you need to hear — until you hear it.
        </motion.p>

        <motion.button
          initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7, delay: 0.1 }}
          whileTap={{ scale: 0.97 }}
          onClick={give}
          className="inline-flex items-center gap-2.5 rounded-full border border-gold/60 bg-card text-charcoal px-8 py-4 text-[0.95rem] shadow-md shadow-gold/10 hover:border-gold hover:shadow-lg hover:shadow-gold/15 transition-all duration-300"
        >
          <Sparkles size={17} className="text-gold" aria-hidden="true" />
          Give Me a Feeling
        </motion.button>

        <div aria-live="polite">
          <AnimatePresence mode="wait">
            {quote && (
              <motion.figure
                key={quote.id}
                initial={{ opacity: 0, y: 18, filter: 'blur(6px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -12, filter: 'blur(6px)' }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
                className="mt-12"
              >
                <blockquote className="font-display text-[clamp(1.4rem,3.5vw,1.9rem)] leading-[1.5] text-charcoal whitespace-pre-line">
                  {quote.quote}
                </blockquote>
                <figcaption className="font-body text-[0.82rem] tracking-[0.16em] text-faint mt-5">
                  #{quote.category.replace(/\s+/g, '')} · — {quote.author || 'SeRuh'}
                </figcaption>
              </motion.figure>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  )
}
