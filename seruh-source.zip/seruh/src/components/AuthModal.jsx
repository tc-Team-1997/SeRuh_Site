import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X } from 'lucide-react'
import { auth } from '../services/auth'
import { api } from '../services/api'
import { useAuth } from '../context/AuthContext'
import { useUi } from '../context/UiContext'

const REASONS = ['Find beautiful thoughts', 'Express my feelings', 'Write better words', 'Save meaningful quotes', 'Explore emotions']
const MOOD_PREFS = ['Romantic', 'Peaceful', 'Hopeful', 'Nostalgic', 'Emotional', 'Thoughtful']

export default function AuthModal() {
  const { wantAuthModal, closeAuth, available, user, refreshProfile } = useAuth()
  const { showToast } = useUi()
  const [tab, setTab] = useState('login')          // login | signup
  const [phase, setPhase] = useState('form')       // form | confirm | onboarding
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [reason, setReason] = useState(null)
  const [moodPref, setMoodPref] = useState(null)

  if (!wantAuthModal) return null

  const inputCls = 'w-full rounded-xl bg-ivory border border-linec px-4 py-3 text-[0.95rem] text-charcoal font-body focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25'
  const labelCls = 'block font-body text-[0.82rem] font-medium text-softink mb-1.5'

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setBusy(true)
    const d = Object.fromEntries(new FormData(e.target).entries())
    try {
      if (tab === 'signup') {
        if ((d.password || '').length < 8) throw new Error('weak')
        const { needsConfirm } = await auth.signUp({ name: d.name?.trim(), email: d.email.trim(), password: d.password })
        api.track?.('signup')
        if (needsConfirm) { setPhase('confirm'); return }
        setPhase('onboarding')
      } else {
        await auth.signIn(d.email.trim(), d.password)
        api.track?.('login')
        showToast('Welcome back ❤️')
        closeAuth()
      }
    } catch (err) {
      const m = String(err?.message || '')
      setError(
        m === 'weak' ? 'Password needs at least 8 characters.'
        : m.toLowerCase().includes('already') ? 'This email already has a SeRuh account — try logging in.'
        : m.toLowerCase().includes('confirm') ? 'Please confirm your email first — check your inbox.'
        : tab === 'signup' ? 'Something went wrong. Please try again.'
        : 'That email or password doesn’t look right.'
      )
    } finally {
      setBusy(false)
    }
  }

  const finishOnboarding = async (skip = false) => {
    try {
      if (!skip) {
        await auth.saveOnboarding({ reason, mood: moodPref })
        if (moodPref) await auth.savePreferences({ preferred_mood: moodPref })
      }
      await refreshProfile()
    } catch { /* soft */ }
    showToast('Welcome to SeRuh ❤️')
    closeAuth()
    setPhase('form')
  }

  return (
    <AnimatePresence>
      <motion.div
        key="auth"
        className="fixed inset-0 z-[85] flex items-center justify-center p-4 overflow-y-auto"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        role="dialog" aria-modal="true" aria-label="Your SeRuh account"
      >
        <div className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm" onClick={closeAuth} />
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ type: 'spring', stiffness: 320, damping: 30 }}
          className="relative w-full max-w-sm rounded-2xl bg-card border border-linec p-8 shadow-2xl my-8"
        >
          <button onClick={closeAuth} aria-label="Close" className="absolute top-4 right-4 p-2 rounded-full text-softink hover:text-charcoal hover:bg-cream transition-colors">
            <X size={17} aria-hidden="true" />
          </button>

          {!available ? (
            <div className="text-center py-6">
              <p className="font-display text-2xl text-charcoal mb-3">Accounts are almost here</p>
              <p className="font-body text-[0.9rem] text-softink">SeRuh accounts open up once the backend is connected. Until then, your likes and saves live safely in this browser.</p>
            </div>
          ) : user ? (
            <div className="text-center py-6">
              <p className="font-display text-2xl text-charcoal">You&rsquo;re already in ❤️</p>
            </div>
          ) : phase === 'confirm' ? (
            <div className="text-center py-6">
              <p className="font-display text-2xl text-charcoal mb-3">One last step 💌</p>
              <p className="font-body text-[0.9rem] text-softink">We&rsquo;ve sent a confirmation link to your email. Open it, then come back and log in.</p>
              <button onClick={() => { setPhase('form'); setTab('login') }} className="mt-6 rounded-full border border-linec px-6 py-2.5 text-[0.88rem] text-softink hover:border-rose hover:text-rosedeep transition-colors">
                Go to login
              </button>
            </div>
          ) : phase === 'onboarding' ? (
            <div className="py-2">
              <p className="font-display text-2xl text-charcoal text-center mb-1.5">What brings you to SeRuh?</p>
              <p className="font-body text-[0.82rem] text-faint text-center mb-5">Just so we can make it feel like yours. (You can skip this.)</p>
              <div className="flex flex-col gap-2 mb-5">
                {REASONS.map(r => (
                  <button key={r} onClick={() => setReason(r)} aria-pressed={reason === r}
                    className={`rounded-xl border px-4 py-2.5 text-[0.88rem] font-body text-left transition-colors ${reason === r ? 'border-rose bg-roseveil text-rosedeep' : 'border-linec text-softink hover:border-rose/60'}`}>
                    {r}
                  </button>
                ))}
              </div>
              <p className="font-body text-[0.8rem] font-medium text-softink mb-2">A mood you return to?</p>
              <div className="flex flex-wrap gap-1.5 mb-7">
                {MOOD_PREFS.map(m => (
                  <button key={m} onClick={() => setMoodPref(moodPref === m ? null : m)} aria-pressed={moodPref === m}
                    className={`rounded-full border px-3.5 py-1.5 text-[0.8rem] font-body transition-colors ${moodPref === m ? 'border-rose bg-rose text-ivory' : 'border-linec text-softink hover:border-rose/60'}`}>
                    {m}
                  </button>
                ))}
              </div>
              <div className="flex gap-2.5">
                <button onClick={() => finishOnboarding(true)} className="flex-1 rounded-full border border-linec px-5 py-3 text-[0.88rem] text-softink hover:border-rose transition-colors">Skip</button>
                <button onClick={() => finishOnboarding(false)} className="flex-1 rounded-full bg-charcoal text-ivory px-5 py-3 text-[0.88rem] hover:bg-rosedeep transition-colors">Done ❤️</button>
              </div>
            </div>
          ) : (
            <>
              <p className="font-display text-3xl text-charcoal text-center mb-1">Se<span className="text-rose">Ruh</span></p>
              <p className="font-body text-[0.82rem] text-faint text-center mb-6">Your feelings, kept safe.</p>

              <div role="tablist" aria-label="Login or sign up" className="grid grid-cols-2 gap-1 rounded-full border border-linec p-1 mb-6">
                {['login', 'signup'].map(t => (
                  <button key={t} role="tab" aria-selected={tab === t} onClick={() => { setTab(t); setError('') }}
                    className={`rounded-full py-2 text-[0.85rem] font-body transition-colors ${tab === t ? 'bg-charcoal text-ivory' : 'text-softink hover:text-rosedeep'}`}>
                    {t === 'login' ? 'Log in' : 'Sign up'}
                  </button>
                ))}
              </div>

              <form onSubmit={submit} className="flex flex-col gap-4">
                {tab === 'signup' && (
                  <div>
                    <label htmlFor="au-name" className={labelCls}>Name</label>
                    <input id="au-name" name="name" required maxLength={80} className={inputCls} autoComplete="name" />
                  </div>
                )}
                <div>
                  <label htmlFor="au-email" className={labelCls}>Email</label>
                  <input id="au-email" name="email" type="email" required className={inputCls} autoComplete="username" />
                </div>
                <div>
                  <label htmlFor="au-pass" className={labelCls}>Password {tab === 'signup' && <span className="text-faint font-normal">(min 8 characters)</span>}</label>
                  <input id="au-pass" name="password" type="password" required minLength={tab === 'signup' ? 8 : undefined} className={inputCls}
                    autoComplete={tab === 'signup' ? 'new-password' : 'current-password'} />
                </div>
                {error && <p role="alert" className="font-body text-[0.85rem] text-rosedeep">{error}</p>}
                <button type="submit" disabled={busy} className="mt-1 rounded-full bg-charcoal text-ivory px-6 py-3.5 text-[0.95rem] hover:bg-rosedeep transition-colors disabled:opacity-60">
                  {busy ? 'One moment…' : tab === 'login' ? 'Welcome back' : 'Begin ❤️'}
                </button>
                {tab === 'signup' && (
                  <p className="font-body text-[0.72rem] text-faint text-center -mt-1">
                    Your saved feelings from this browser will move into your account.
                  </p>
                )}
              </form>
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
