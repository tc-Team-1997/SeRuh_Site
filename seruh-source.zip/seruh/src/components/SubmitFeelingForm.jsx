import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Send } from 'lucide-react'
import { MOODS, CATEGORIES } from '../data/quotes'
import { api } from '../services/api'
import { useUi } from '../context/UiContext'
import { useData } from '../context/DataContext'

export default function SubmitFeelingForm() {
  const { showToast } = useUi()
  const { categories } = useData()
  const [anonymous, setAnonymous] = useState(false)
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)

  const categoryOptions = categories.length ? categories : CATEGORIES.map(c => c.label)

  const onSubmit = async (e) => {
    e.preventDefault()
    const form = e.target
    const data = Object.fromEntries(new FormData(form).entries())

    const content = (data.quote || '').trim()
    if (content.length < 3) { showToast('Give your feeling a few more words.'); return }
    if (content.length > 1000) { showToast('A little shorter, maybe — 1000 characters at most.'); return }

    setSending(true)
    try {
      await api.submitFeeling({
        content,
        category: data.category,
        mood: data.mood,
        anonymous,
        name: anonymous ? '' : (data.name || '').trim(),
        email: (data.email || '').trim(),
        honeypot: data['bot-field'] || '',
      })
      setSent(true)
      form.reset()
      setAnonymous(false)
      api.track?.('feeling_submit')
      showToast('Your feeling has been received. ❤️')
    } catch (err) {
      const msg = String(err?.message || '')
      if (msg.includes('rate') || msg.includes('slow')) {
        showToast('Take a breath — you can share again in a little while. 🕊️')
      } else {
        showToast('Something went wrong. Please try again.')
      }
    } finally {
      setSending(false)
    }
  }

  const inputCls =
    'w-full rounded-xl bg-ivory border border-linec px-4.5 py-3 text-[0.95rem] text-charcoal ' +
    'placeholder:text-faint focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25 transition-shadow font-body'
  const labelCls = 'block font-body text-[0.82rem] font-medium text-softink mb-2'

  return (
    <section id="write" className="relative py-24 sm:py-28 px-5">
      <div className="mx-auto max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <p className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-4">Your turn</p>
          <h2 className="font-display text-[clamp(2.1rem,5vw,3rem)] text-charcoal">Write Your Feeling</h2>
          <p className="font-body text-softink mt-3">Some thoughts deserve a place outside your mind.</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-[1.5rem] bg-card border border-linec p-7 sm:p-10 shadow-xl shadow-charcoal/[0.05]"
        >
          <AnimatePresence mode="wait">
            {sent ? (
              <motion.div
                key="done"
                initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="text-center py-14"
              >
                <p className="font-display text-3xl text-charcoal mb-3">Your feeling has been received. ❤️</p>
                <p className="font-body text-softink mb-8">
                  It will be read gently, and may soon find its place on the Unsaid Feelings wall.
                </p>
                <button
                  onClick={() => setSent(false)}
                  className="rounded-full border border-linec px-6 py-2.5 text-[0.88rem] text-softink hover:border-rose hover:text-rosedeep transition-colors"
                >
                  Write another
                </button>
              </motion.div>
            ) : (
              <motion.form
                key="form"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, y: -10 }}
                name="seruh-feelings"
                method="POST"
                data-netlify="true"
                netlify-honeypot="bot-field"
                onSubmit={onSubmit}
                className="flex flex-col gap-5"
              >
                <input type="hidden" name="form-name" value="seruh-feelings" />
                <p className="hidden" aria-hidden="true">
                  <label>Leave this field empty: <input name="bot-field" tabIndex={-1} autoComplete="off" /></label>
                </p>

                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="sf-name" className={labelCls}>Name <span className="text-faint font-normal">(optional)</span></label>
                    <input id="sf-name" name="name" type="text" placeholder={anonymous ? 'Staying anonymous 🕊️' : 'How should we remember you?'} className={inputCls} disabled={anonymous} />
                  </div>
                  <div>
                    <label htmlFor="sf-email" className={labelCls}>Email <span className="text-faint font-normal">(optional — never shown publicly)</span></label>
                    <input id="sf-email" name="email" type="email" placeholder="Only if you'd like us to reply" className={inputCls} />
                  </div>
                </div>

                <div>
                  <label htmlFor="sf-quote" className={labelCls}>Your Quote <span className="text-rose">*</span></label>
                  <textarea
                    id="sf-quote" name="quote" required rows={5} maxLength={1000}
                    placeholder="Write what you've been unable to say…"
                    className={`${inputCls} resize-y font-display text-lg leading-relaxed`}
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="sf-category" className={labelCls}>Category</label>
                    <select id="sf-category" name="category" className={inputCls} defaultValue="Heartfelt">
                      {categoryOptions.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="sf-mood" className={labelCls}>Mood</label>
                    <select id="sf-mood" name="mood" className={inputCls} defaultValue="Emotional">
                      {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-xl bg-ivory border border-linec px-4.5 py-3.5">
                  <span className="font-body text-[0.9rem] text-softink">
                    Share anonymously
                    <span className="block text-[0.75rem] text-faint">Your name will never be shown — only &ldquo;Anonymous&rdquo;.</span>
                  </span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={anonymous}
                    aria-label="Share anonymously"
                    onClick={() => setAnonymous(v => !v)}
                    className={`relative h-6.5 w-12 shrink-0 rounded-full transition-colors duration-300 ${anonymous ? 'bg-rose' : 'bg-linec'}`}
                  >
                    <span className={`absolute top-0.5 h-5.5 w-5.5 rounded-full bg-card shadow transition-all duration-300 ${anonymous ? 'left-6' : 'left-0.5'}`} />
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={sending}
                  className="mt-2 inline-flex items-center justify-center gap-2.5 rounded-full bg-charcoal text-ivory px-8 py-4 text-[0.95rem] hover:bg-rosedeep transition-colors duration-300 disabled:opacity-60"
                >
                  <Send size={16} aria-hidden="true" />
                  {sending ? 'Sending…' : 'Send It Into The World ✨'}
                </button>
                <p className="font-body text-[0.75rem] text-faint text-center -mt-1">
                  Every feeling is reviewed gently before it appears on the wall.
                </p>
              </motion.form>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  )
}
