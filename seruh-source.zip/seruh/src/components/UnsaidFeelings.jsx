import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Heart, Copy, Share2 } from 'lucide-react'
import { api } from '../services/api'
import { useUi } from '../context/UiContext'
import { useData } from '../context/DataContext'
import { RowSkeleton } from './Skeleton'

const PAGE_SIZE = 10

export default function UnsaidFeelings() {
  const [items, setItems] = useState([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const { copyQuote, openShare } = useUi()
  const { likedFeelings, toggleFeelingLike, feelingCountOf } = useData()

  useEffect(() => {
    let alive = true
    api.getPublicFeelings({ page: 0, pageSize: PAGE_SIZE })
      .then(res => { if (alive) { setItems(res.items); setTotal(res.total); setLoading(false) } })
      .catch(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [])

  const loadMore = async () => {
    setLoadingMore(true)
    try {
      const res = await api.getPublicFeelings({ page: page + 1, pageSize: PAGE_SIZE })
      setItems(prev => [...prev, ...res.items])
      setTotal(res.total)
      setPage(p => p + 1)
    } catch { /* quiet */ }
    setLoadingMore(false)
  }

  return (
    <section id="unsaid" className="relative py-24 sm:py-28 px-5">
      <div className="mx-auto max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <p className="font-body text-[11px] tracking-[0.32em] uppercase text-gold mb-4">The wall</p>
          <h2 className="font-display text-[clamp(2.1rem,5vw,3rem)] text-charcoal">Unsaid Feelings</h2>
          <p className="font-body text-softink mt-3 max-w-md mx-auto">
            Real feelings, left here quietly by people like you. Shared with care, kept anonymous.
          </p>
        </motion.div>

        {loading ? (
          <RowSkeleton rows={4} />
        ) : items.length === 0 ? (
          <div className="text-center py-14">
            <p className="font-display text-2xl text-charcoal mb-3">The wall is waiting for its first feeling.</p>
            <p className="font-body text-softink mb-7">Maybe it&rsquo;s yours.</p>
            <a href="#write" className="inline-block rounded-full bg-charcoal text-ivory px-7 py-3 text-[0.92rem] hover:bg-rosedeep transition-colors duration-300">
              Write Your Feeling
            </a>
          </div>
        ) : (
          <div className="relative">
            {/* thread line */}
            <div aria-hidden="true" className="absolute left-4 sm:left-1/2 top-2 bottom-2 w-px bg-linec" />
            <div className="flex flex-col gap-10">
              {items.map((f, i) => {
                const liked = likedFeelings.has(f.id)
                return (
                  <motion.article
                    key={f.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-30px' }}
                    transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                    className={`relative pl-12 sm:pl-0 sm:w-[calc(50%-2rem)] ${i % 2 ? 'sm:ml-auto' : ''}`}
                  >
                    {/* node dot */}
                    <span aria-hidden="true" className={`absolute top-6 left-[13px] sm:left-auto h-2 w-2 rounded-full bg-rose ${i % 2 ? 'sm:-left-[2.32rem]' : 'sm:-right-[2.32rem]'}`} />
                    <div className="rounded-2xl bg-card border border-linec p-6 sm:p-7 transition-all duration-400 hover:border-rose/45 hover:shadow-lg hover:shadow-rose/[0.07]">
                      <blockquote className="font-display text-[1.15rem] leading-[1.6] text-charcoal whitespace-pre-line">
                        &ldquo;{f.content}&rdquo;
                      </blockquote>
                      <p className="font-body text-[0.78rem] text-faint mt-4">
                        — {f.display_name || 'Anonymous'} <span aria-hidden="true">·</span>{' '}
                        <span className="text-rose">#{(f.category || '').replace(/\s+/g, '')}</span>
                      </p>
                      <div className="mt-4 pt-3.5 border-t border-linec/70 flex items-center gap-0.5">
                        <button
                          onClick={() => toggleFeelingLike(f)}
                          aria-pressed={liked}
                          aria-label={liked ? 'Unlike this feeling' : 'Like this feeling'}
                          className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] tabular-nums transition-colors duration-300 ${
                            liked ? 'text-rosedeep bg-roseveil' : 'text-softink hover:text-rosedeep hover:bg-roseveil/60'
                          }`}
                        >
                          <Heart size={14} className={liked ? 'fill-rose text-rose' : ''} aria-hidden="true" />
                          {feelingCountOf(f)}
                        </button>
                        <button
                          onClick={() => copyQuote({ quote: f.content })}
                          aria-label="Copy this feeling"
                          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors duration-300"
                        >
                          <Copy size={14} aria-hidden="true" /> Copy
                        </button>
                        <button
                          onClick={() => openShare({ quote: f.content })}
                          aria-label="Share this feeling"
                          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors duration-300"
                        >
                          <Share2 size={14} aria-hidden="true" /> Share
                        </button>
                      </div>
                    </div>
                  </motion.article>
                )
              })}
            </div>
            {items.length < total && (
              <div className="text-center mt-12">
                <button
                  onClick={loadMore}
                  disabled={loadingMore}
                  className="rounded-full border border-linec bg-card px-7 py-3 text-[0.88rem] text-softink hover:border-rose hover:text-rosedeep transition-colors disabled:opacity-60"
                >
                  {loadingMore ? 'Listening…' : 'More unsaid feelings'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  )
}
