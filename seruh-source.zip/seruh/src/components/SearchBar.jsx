import { Search, X } from 'lucide-react'

export default function SearchBar({ value, onChange }) {
  return (
    <div className="relative max-w-xl mx-auto">
      <Search size={17} aria-hidden="true" className="absolute left-5 top-1/2 -translate-y-1/2 text-faint" />
      <label htmlFor="quote-search" className="sr-only">Search a feeling, thought or word</label>
      <input
        id="quote-search"
        type="search"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder="Search a feeling, thought or word…"
        className="w-full rounded-full bg-card border border-linec pl-12 pr-11 py-3.5 text-[0.95rem] text-charcoal placeholder:text-faint focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25 transition-shadow font-body"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          aria-label="Clear search"
          className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-full text-faint hover:text-charcoal transition-colors"
        >
          <X size={15} aria-hidden="true" />
        </button>
      )}
    </div>
  )
}
