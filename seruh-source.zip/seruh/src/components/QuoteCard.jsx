import { motion } from 'framer-motion'
import { Heart, Copy, Share2, Bookmark } from 'lucide-react'
import { useUi } from '../context/UiContext'
import { useData } from '../context/DataContext'

export default function QuoteCard({ quote, index = 0 }) {
  const { copyQuote, openShare } = useUi()
  const { likedQuotes, savedMap, toggleQuoteLike, toggleQuoteSave, likeCountOf } = useData()

  const liked = likedQuotes.has(quote.id)
  const saved = savedMap.has(quote.id)
  const count = likeCountOf(quote)
  const tag = `#${quote.category.replace(/\s+/g, '')}`

  return (
    <motion.article
      initial={{ opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.6, delay: (index % 3) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="group relative mb-5 break-inside-avoid rounded-2xl bg-card border border-linec p-7 sm:p-8
                 transition-all duration-400 hover:border-rose/45 hover:shadow-lg hover:shadow-rose/[0.07] hover:-translate-y-0.5"
    >
      <blockquote className="font-display text-[1.28rem] leading-[1.55] text-charcoal whitespace-pre-line">
        {quote.quote}
      </blockquote>

      <div className="mt-5 flex flex-wrap items-center gap-x-3 gap-y-1 font-body">
        <span className="text-[0.78rem] text-rose">{tag}</span>
        <span aria-hidden="true" className="text-linec">·</span>
        <span className="text-[0.78rem] text-faint italic">{quote.mood}</span>
        {quote.author && (
          <>
            <span aria-hidden="true" className="text-linec">·</span>
            <span className="text-[0.78rem] text-softink">— {quote.author}</span>
          </>
        )}
      </div>

      <div className="mt-5 pt-4 border-t border-linec/70 flex items-center gap-0.5 flex-wrap">
        <button
          onClick={() => toggleQuoteLike(quote)}
          aria-pressed={liked}
          aria-label={liked ? `Unlike this quote (${count} likes)` : `Like this quote (${count} likes)`}
          className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] tabular-nums transition-colors duration-300 ${
            liked ? 'text-rosedeep bg-roseveil' : 'text-softink hover:text-rosedeep hover:bg-roseveil/60'
          }`}
        >
          <Heart size={14} className={liked ? 'fill-rose text-rose' : ''} aria-hidden="true" />
          {count}
        </button>
        <button
          onClick={() => toggleQuoteSave(quote)}
          aria-pressed={saved}
          aria-label={saved ? 'Remove from saved' : 'Save for later'}
          className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] transition-colors duration-300 ${
            saved ? 'text-rosedeep bg-roseveil' : 'text-softink hover:text-rosedeep hover:bg-roseveil/60'
          }`}
        >
          <Bookmark size={14} className={saved ? 'fill-rose text-rose' : ''} aria-hidden="true" />
          {saved ? 'Saved' : 'Save'}
        </button>
        <button
          onClick={() => copyQuote(quote)}
          aria-label="Copy this quote"
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors duration-300"
        >
          <Copy size={14} aria-hidden="true" /> Copy
        </button>
        <button
          onClick={() => openShare(quote)}
          aria-label="Share this quote"
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[0.8rem] text-softink hover:text-rosedeep hover:bg-roseveil/60 transition-colors duration-300"
        >
          <Share2 size={14} aria-hidden="true" /> Share
        </button>
      </div>
    </motion.article>
  )
}
