import { useState } from 'react'
import { LayoutDashboard, Quote, Inbox, Tags, BarChart3, Sparkles, ExternalLink, LogOut, Menu, X } from 'lucide-react'
import Overview from './pages/Overview'
import QuotesAdmin from './pages/QuotesAdmin'
import Submissions from './pages/Submissions'
import CategoriesAdmin from './pages/CategoriesAdmin'
import Analytics from './pages/Analytics'
import AiSettings from './pages/AiSettings'

const PAGES = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard, el: Overview },
  { key: 'analytics', label: 'SeRuh Analytics', icon: BarChart3, el: Analytics },
  { key: 'quotes', label: 'Manage Quotes', icon: Quote, el: QuotesAdmin },
  { key: 'submissions', label: 'Feeling Submissions', icon: Inbox, el: Submissions },
  { key: 'categories', label: 'Categories', icon: Tags, el: CategoriesAdmin },
  { key: 'ai', label: 'AI Settings', icon: Sparkles, el: AiSettings },
]

export default function AdminShell({ onSignOut }) {
  const [page, setPage] = useState('overview')
  const [navOpen, setNavOpen] = useState(false)
  const Current = PAGES.find(p => p.key === page).el

  return (
    <div className="min-h-svh bg-ivory flex">
      {/* sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-charcoal text-ivory flex flex-col transition-transform duration-300 ${navOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="px-6 py-6 border-b border-ivory/10">
          <p className="font-display text-2xl">Se<span className="text-rose">Ruh</span></p>
          <p className="font-body text-[0.68rem] tracking-[0.28em] uppercase text-gold mt-1">Admin</p>
        </div>
        <nav aria-label="Admin" className="flex-1 px-3 py-4 flex flex-col gap-1">
          {PAGES.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => { setPage(key); setNavOpen(false) }}
              aria-current={page === key ? 'page' : undefined}
              className={`flex items-center gap-3 rounded-xl px-4 py-3 text-[0.9rem] font-body text-left transition-colors ${
                page === key ? 'bg-ivory/10 text-ivory' : 'text-ivory/60 hover:text-ivory hover:bg-ivory/5'
              }`}
            >
              <Icon size={17} aria-hidden="true" /> {label}
            </button>
          ))}
        </nav>
        <div className="px-3 pb-5 flex flex-col gap-1 border-t border-ivory/10 pt-4">
          <a href="#home" onClick={() => setTimeout(() => location.reload(), 50)} className="flex items-center gap-3 rounded-xl px-4 py-3 text-[0.9rem] font-body text-ivory/60 hover:text-ivory hover:bg-ivory/5 transition-colors">
            <ExternalLink size={17} aria-hidden="true" /> View site
          </a>
          <button onClick={onSignOut} className="flex items-center gap-3 rounded-xl px-4 py-3 text-[0.9rem] font-body text-ivory/60 hover:text-ivory hover:bg-ivory/5 transition-colors text-left">
            <LogOut size={17} aria-hidden="true" /> Sign out
          </button>
        </div>
      </aside>

      {/* overlay for mobile nav */}
      {navOpen && <div className="fixed inset-0 z-30 bg-charcoal/40 lg:hidden" onClick={() => setNavOpen(false)} />}

      {/* main */}
      <div className="flex-1 min-w-0">
        <header className="lg:hidden sticky top-0 z-20 bg-ivory/90 backdrop-blur border-b border-linec px-4 h-14 flex items-center gap-3">
          <button onClick={() => setNavOpen(v => !v)} aria-label={navOpen ? 'Close admin menu' : 'Open admin menu'} className="p-2 rounded-full text-charcoal hover:bg-cream">
            {navOpen ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
          </button>
          <span className="font-display text-xl text-charcoal">Se<span className="text-rose">Ruh</span> <span className="font-body text-xs text-gold uppercase tracking-widest ml-1">Admin</span></span>
        </header>
        <main className="p-5 sm:p-8 lg:p-10 max-w-6xl">
          <Current />
        </main>
      </div>
    </div>
  )
}
