import { useState } from 'react'
import { motion } from 'framer-motion'
import { Lock } from 'lucide-react'
import { adminApi } from './adminApi'

export default function AdminLogin({ onSuccess }) {
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    const { email, password } = Object.fromEntries(new FormData(e.target).entries())
    setBusy(true); setError('')
    try {
      await adminApi.signIn(email.trim(), password)
      onSuccess()
    } catch (err) {
      setError(err?.message === 'not-admin'
        ? 'This account does not have admin access.'
        : 'That email or password doesn’t look right.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-svh bg-ivory flex items-center justify-center px-5">
      <motion.div
        initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-sm rounded-2xl bg-card border border-linec shadow-xl shadow-charcoal/[0.06] p-9"
      >
        <div className="text-center mb-8">
          <p className="font-display text-3xl text-charcoal">Se<span className="text-rose">Ruh</span></p>
          <p className="font-body text-[0.8rem] tracking-[0.24em] uppercase text-gold mt-2 flex items-center justify-center gap-1.5">
            <Lock size={12} aria-hidden="true" /> Admin
          </p>
        </div>

        <form onSubmit={submit} className="flex flex-col gap-4">
          <div>
            <label htmlFor="ad-email" className="block font-body text-[0.82rem] font-medium text-softink mb-1.5">Email</label>
            <input
              id="ad-email" name="email" type="email" required autoComplete="username"
              className="w-full rounded-xl bg-ivory border border-linec px-4 py-3 text-[0.95rem] text-charcoal focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25 font-body"
            />
          </div>
          <div>
            <label htmlFor="ad-pass" className="block font-body text-[0.82rem] font-medium text-softink mb-1.5">Password</label>
            <input
              id="ad-pass" name="password" type="password" required autoComplete="current-password"
              className="w-full rounded-xl bg-ivory border border-linec px-4 py-3 text-[0.95rem] text-charcoal focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25 font-body"
            />
          </div>
          {error && <p className="font-body text-[0.85rem] text-rosedeep" role="alert">{error}</p>}
          <button
            type="submit" disabled={busy}
            className="mt-2 rounded-full bg-charcoal text-ivory px-6 py-3.5 text-[0.95rem] hover:bg-rosedeep transition-colors disabled:opacity-60"
          >
            {busy ? 'Signing in…' : 'Enter'}
          </button>
        </form>
        <a href="#home" onClick={() => setTimeout(() => location.reload(), 50)} className="block text-center font-body text-[0.8rem] text-faint hover:text-softink mt-6 transition-colors">
          ← Back to SeRuh
        </a>
      </motion.div>
    </div>
  )
}
