// Admin data access — every call here is protected by Row Level
// Security on the database: only authenticated users present in
// the `admins` table can read or write these tables.

import { supabase } from '../lib/supabase'

const PAGE = 20

export const adminApi = {
  /* ── auth ─────────────────────────────────────────── */
  async signIn(email, password) {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    const ok = await this.amIAdmin()
    if (!ok) {
      await supabase.auth.signOut()
      throw new Error('not-admin')
    }
  },
  async signOut() { await supabase.auth.signOut() },
  async getSession() { return (await supabase.auth.getSession()).data.session },
  onAuthChange(cb) { return supabase.auth.onAuthStateChange((_e, s) => cb(s)) },
  async amIAdmin() {
    const { data, error } = await supabase.rpc('am_i_admin')
    if (error) return false
    return data === true
  },

  /* ── stats ────────────────────────────────────────── */
  async stats() {
    const count = (table, filter) => {
      let q = supabase.from(table).select('id', { count: 'exact', head: true })
      if (filter) q = filter(q)
      return q.then(r => r.count ?? 0)
    }
    const [quotes, feelings, pendingSubs, likes, saves] = await Promise.all([
      count('quotes'),
      count('feelings'),
      count('feelings', q => q.eq('status', 'PENDING')),
      count('quote_likes'),
      count('saved_quotes'),
    ])
    return { quotes, feelings, pendingSubs, likes, saves }
  },

  /* ── categories ───────────────────────────────────── */
  async listCategories() {
    const { data, error } = await supabase.from('categories').select('*').order('sort')
    if (error) throw error
    return data
  },
  async createCategory(name, description = '') {
    const { error } = await supabase.from('categories').insert({ name, description })
    if (error) throw error
  },
  async updateCategory(id, patch) {
    const { error } = await supabase.from('categories').update(patch).eq('id', id)
    if (error) throw error
  },

  /* ── quotes ───────────────────────────────────────── */
  async listQuotes({ page = 0, status = null, categoryId = null, featured = null, search = '' } = {}) {
    let q = supabase.from('quotes')
      .select('*, categories(name)', { count: 'exact' })
      .order('created_at', { ascending: false })
    if (status) q = q.eq('status', status)
    if (categoryId) q = q.eq('category_id', categoryId)
    if (featured !== null) q = q.eq('featured', featured)
    const s = search.trim()
    if (s) q = q.ilike('quote', `%${s}%`)
    const from = page * PAGE
    const { data, count, error } = await q.range(from, from + PAGE - 1)
    if (error) throw error
    return { items: data, total: count ?? 0, pageSize: PAGE }
  },
  async createQuote(fields) {
    const { error } = await supabase.from('quotes').insert(fields)
    if (error) throw error
  },
  async updateQuote(id, patch) {
    const { error } = await supabase.from('quotes').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', id)
    if (error) throw error
  },
  async deleteQuote(id) {
    const { error } = await supabase.from('quotes').delete().eq('id', id)
    if (error) throw error
  },

  /* ── feeling submissions ──────────────────────────── */
  async listFeelings({ page = 0, status = 'PENDING' } = {}) {
    let q = supabase.from('feelings')
      .select('*, categories(name)', { count: 'exact' })
      .order('created_at', { ascending: false })
      .eq('status', status)
    const from = page * PAGE
    const { data, count, error } = await q.range(from, from + PAGE - 1)
    if (error) throw error
    return { items: data, total: count ?? 0, pageSize: PAGE }
  },
  async setFeelingStatus(id, status) {
    const { error } = await supabase.from('feelings').update({ status, updated_at: new Date().toISOString() }).eq('id', id)
    if (error) throw error
  },

  /* ── Phase 3: analytics (aggregated on the database) ── */
  async analyticsOverview(from, to) {
    const { data, error } = await supabase.rpc('admin_analytics_overview', { p_from: from, p_to: to })
    if (error) throw error
    return data
  },
  async topQuotes(from, to, by = 'likes', limit = 10) {
    const { data, error } = await supabase.rpc('admin_top_quotes', { p_from: from, p_to: to, p_by: by, p_limit: limit })
    if (error) throw error
    return data ?? []
  },
  async categoryStats(from, to) {
    const { data, error } = await supabase.rpc('admin_category_stats', { p_from: from, p_to: to })
    if (error) throw error
    return data ?? []
  },
  async aiStats(from, to) {
    const { data, error } = await supabase.rpc('admin_ai_stats', { p_from: from, p_to: to })
    if (error) throw error
    return data
  },

  /* ── Phase 3: AI settings ── */
  async getAiSettings() {
    const { data, error } = await supabase.from('ai_settings').select('*').eq('id', 1).single()
    if (error) throw error
    return data
  },
  async saveAiSettings(patch) {
    const { error } = await supabase.from('ai_settings')
      .update({ ...patch, updated_at: new Date().toISOString() }).eq('id', 1)
    if (error) throw error
  },
}
