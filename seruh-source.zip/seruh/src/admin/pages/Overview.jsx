import { useEffect, useState } from 'react'
import { Quote, Inbox, Clock, Heart, Bookmark } from 'lucide-react'
import { adminApi } from '../adminApi'
import { RowSkeleton } from '../../components/Skeleton'

const CARDS = [
  { key: 'quotes', label: 'Total Quotes', icon: Quote },
  { key: 'feelings', label: 'Total Feelings', icon: Inbox },
  { key: 'pendingSubs', label: 'Pending Submissions', icon: Clock, highlight: true },
  { key: 'likes', label: 'Total Likes', icon: Heart },
  { key: 'saves', label: 'Saved Quotes', icon: Bookmark },
]

export default function Overview() {
  const [stats, setStats] = useState(null)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    adminApi.stats().then(setStats).catch(() => setFailed(true))
  }, [])

  return (
    <div>
      <h1 className="font-display text-3xl text-charcoal mb-2">Overview</h1>
      <p className="font-body text-softink text-[0.92rem] mb-8">How SeRuh is feeling today.</p>

      {failed ? (
        <p className="font-body text-softink">Couldn&rsquo;t load statistics. Please refresh.</p>
      ) : !stats ? (
        <RowSkeleton rows={2} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {CARDS.map(({ key, label, icon: Icon, highlight }) => (
            <div
              key={key}
              className={`rounded-2xl border p-6 ${
                highlight && stats[key] > 0
                  ? 'bg-roseveil border-rose/40'
                  : 'bg-card border-linec'
              }`}
            >
              <div className="flex items-center gap-2.5 mb-3">
                <Icon size={16} aria-hidden="true" className={highlight && stats[key] > 0 ? 'text-rosedeep' : 'text-gold'} />
                <p className="font-body text-[0.78rem] tracking-[0.14em] uppercase text-softink">{label}</p>
              </div>
              <p className="font-display text-4xl text-charcoal tabular-nums">{stats[key].toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
