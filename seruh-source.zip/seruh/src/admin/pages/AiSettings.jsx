import { useEffect, useState } from 'react'
import { adminApi } from '../adminApi'
import { useUi } from '../../context/UiContext'
import { RowSkeleton } from '../../components/Skeleton'

export default function AiSettings() {
  const { showToast } = useUi()
  const [s, setS] = useState(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    adminApi.getAiSettings().then(setS).catch(() => showToast('Something went wrong. Please refresh.'))
  }, [showToast])

  const inputCls = 'w-full rounded-xl bg-ivory border border-linec px-4 py-2.5 text-[0.92rem] text-charcoal font-body focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25'
  const labelCls = 'block font-body text-[0.8rem] font-medium text-softink mb-1.5'

  const save = async (e) => {
    e.preventDefault()
    const d = Object.fromEntries(new FormData(e.target).entries())
    setBusy(true)
    try {
      await adminApi.saveAiSettings({
        provider: d.provider, model: d.model.trim(),
        guest_daily_limit: Number(d.guest_daily_limit),
        user_daily_limit: Number(d.user_daily_limit),
        max_input_length: Number(d.max_input_length),
        max_output_words: Number(d.max_output_words),
        temperature: Number(d.temperature),
      })
      showToast('AI settings saved ✨')
    } catch {
      showToast('Something went wrong. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  if (!s) return <div><h1 className="font-display text-3xl text-charcoal mb-6">AI Settings</h1><RowSkeleton rows={5} /></div>

  return (
    <div className="max-w-xl">
      <h1 className="font-display text-3xl text-charcoal mb-2">AI Settings</h1>
      <p className="font-body text-softink text-[0.92rem] mb-7">
        How SeRuh finds its words. The AI provider&rsquo;s API key lives only in the Edge Function secrets — it is never stored here or in the website.
      </p>

      <form onSubmit={save} className="rounded-2xl bg-card border border-linec p-7 flex flex-col gap-5">
        <div className="grid sm:grid-cols-2 gap-5">
          <div>
            <label htmlFor="ai-provider" className={labelCls}>Provider</label>
            <select id="ai-provider" name="provider" defaultValue={s.provider} className={inputCls}>
              <option value="gemini">Google Gemini</option>
            </select>
          </div>
          <div>
            <label htmlFor="ai-model" className={labelCls}>Model</label>
            <input id="ai-model" name="model" defaultValue={s.model} className={inputCls} />
          </div>
        </div>
        <div className="grid sm:grid-cols-2 gap-5">
          <div>
            <label htmlFor="ai-guest" className={labelCls}>Guest daily limit</label>
            <input id="ai-guest" name="guest_daily_limit" type="number" min="0" max="1000" defaultValue={s.guest_daily_limit} className={inputCls} />
          </div>
          <div>
            <label htmlFor="ai-user" className={labelCls}>Member daily limit</label>
            <input id="ai-user" name="user_daily_limit" type="number" min="0" max="5000" defaultValue={s.user_daily_limit} className={inputCls} />
          </div>
        </div>
        <div className="grid sm:grid-cols-3 gap-5">
          <div>
            <label htmlFor="ai-inlen" className={labelCls}>Max input chars</label>
            <input id="ai-inlen" name="max_input_length" type="number" min="50" max="1000" defaultValue={s.max_input_length} className={inputCls} />
          </div>
          <div>
            <label htmlFor="ai-outlen" className={labelCls}>Max output words</label>
            <input id="ai-outlen" name="max_output_words" type="number" min="10" max="200" defaultValue={s.max_output_words} className={inputCls} />
          </div>
          <div>
            <label htmlFor="ai-temp" className={labelCls}>Creativity (0–2)</label>
            <input id="ai-temp" name="temperature" type="number" step="0.1" min="0" max="2" defaultValue={s.temperature} className={inputCls} />
          </div>
        </div>
        <button type="submit" disabled={busy} className="self-start rounded-full bg-charcoal text-ivory px-6 py-3 text-[0.9rem] hover:bg-rosedeep transition-colors disabled:opacity-60">
          {busy ? 'Saving…' : 'Save settings'}
        </button>
      </form>
    </div>
  )
}
