import { useCallback, useEffect, useState } from 'react'
import { Plus, Pencil, Check, Power } from 'lucide-react'
import { adminApi } from '../adminApi'
import { useUi } from '../../context/UiContext'
import { RowSkeleton } from '../../components/Skeleton'

export default function CategoriesAdmin() {
  const { showToast } = useUi()
  const [cats, setCats] = useState(null)
  const [newName, setNewName] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [editName, setEditName] = useState('')

  const load = useCallback(() => {
    adminApi.listCategories().then(setCats).catch(() => showToast('Something went wrong. Please try again.'))
  }, [showToast])

  useEffect(() => { load() }, [load])

  const add = async (e) => {
    e.preventDefault()
    const name = newName.trim()
    if (name.length < 2) { showToast('Give the category a real name.'); return }
    try { await adminApi.createCategory(name); setNewName(''); showToast('Category added'); load() }
    catch { showToast('Something went wrong — maybe that name already exists.') }
  }

  const saveEdit = async (id) => {
    const name = editName.trim()
    if (name.length < 2) { showToast('Give the category a real name.'); return }
    try { await adminApi.updateCategory(id, { name }); setEditingId(null); showToast('Category renamed'); load() }
    catch { showToast('Something went wrong. Please try again.') }
  }

  const toggleActive = async (c) => {
    const next = c.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE'
    try { await adminApi.updateCategory(c.id, { status: next }); showToast(next === 'ACTIVE' ? 'Category activated' : 'Category deactivated'); load() }
    catch { showToast('Something went wrong. Please try again.') }
  }

  const inputCls = 'rounded-xl bg-ivory border border-linec px-4 py-2.5 text-[0.92rem] text-charcoal font-body focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25'

  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-3xl text-charcoal mb-2">Categories</h1>
      <p className="font-body text-softink text-[0.92rem] mb-7">
        The feelings people can explore by. Deactivated categories disappear from the public site but keep their quotes.
      </p>

      <form onSubmit={add} className="flex gap-2.5 mb-7">
        <label htmlFor="new-cat" className="sr-only">New category name</label>
        <input id="new-cat" value={newName} onChange={e => setNewName(e.target.value)} placeholder="New category name…" className={`${inputCls} flex-1`} />
        <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-charcoal text-ivory px-5 py-2.5 text-[0.88rem] hover:bg-rosedeep transition-colors">
          <Plus size={15} aria-hidden="true" /> Add
        </button>
      </form>

      {!cats ? (
        <RowSkeleton rows={6} />
      ) : (
        <div className="flex flex-col gap-2.5">
          {cats.map(c => (
            <div key={c.id} className={`rounded-xl border p-4 flex items-center gap-3 ${c.status === 'ACTIVE' ? 'bg-card border-linec' : 'bg-cream border-linec opacity-70'}`}>
              {editingId === c.id ? (
                <>
                  <label htmlFor={`cat-${c.id}`} className="sr-only">Category name</label>
                  <input id={`cat-${c.id}`} value={editName} onChange={e => setEditName(e.target.value)} className={`${inputCls} flex-1`} />
                  <button onClick={() => saveEdit(c.id)} aria-label="Save name" className="p-2.5 rounded-full text-emerald-700 hover:bg-emerald-50 transition-colors"><Check size={16} aria-hidden="true" /></button>
                </>
              ) : (
                <>
                  <span className="font-body text-[0.95rem] text-charcoal flex-1">
                    {c.name}
                    {c.status !== 'ACTIVE' && <span className="ml-2 text-[0.72rem] text-faint uppercase tracking-wider">inactive</span>}
                  </span>
                  <button onClick={() => { setEditingId(c.id); setEditName(c.name) }} aria-label={`Rename ${c.name}`} className="p-2.5 rounded-full text-softink hover:text-rosedeep hover:bg-roseveil/70 transition-colors">
                    <Pencil size={15} aria-hidden="true" />
                  </button>
                  <button onClick={() => toggleActive(c)} aria-label={c.status === 'ACTIVE' ? `Deactivate ${c.name}` : `Activate ${c.name}`} title={c.status === 'ACTIVE' ? 'Deactivate' : 'Activate'} className="p-2.5 rounded-full text-softink hover:text-rosedeep hover:bg-roseveil/70 transition-colors">
                    <Power size={15} aria-hidden="true" />
                  </button>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
