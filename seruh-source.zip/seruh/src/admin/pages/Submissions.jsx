import { useCallback, useEffect, useState } from 'react'
import { Check, X as XIcon, Archive, Mail } from 'lucide-react'
import { adminApi } from '../adminApi'
import { useUi } from '../../context/UiContext'
import { RowSkeleton } from '../../components/Skeleton'
import { StatusPill } from './QuotesAdmin'

const TABS = ['PENDING', 'APPROVED', 'REJECTED', 'ARCHIVED']

function fmt(iso) {
  try { return new Date(iso).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) }
  catch { return '' }
}

export default function Submissions() {
  const { showToast } = useUi()
  const [tab, setTab] = useState('PENDING')
  const [page, setPage] = useState(0)
  const [data, setData] = useState(null)

  const load = useCallback(() => {
    setData(null)
    adminApi.listFeelings({ page, status: tab })
      .then(setData)
      .catch(() => showToast('Something went wrong. Please try again.'))
  }, [page, tab, showToast])

  useEffect(() => { load() }, [load])

  const act = async (id, status, msg) => {
    try { await adminApi.setFeelingStatus(id, status); showToast(msg); load() }
    catch { showToast('Something went wrong. Please try again.') }
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1

  return (
    <div>
      <h1 className="font-display text-3xl text-charcoal mb-2">Feeling Submissions</h1>
      <p className="font-body text-softink text-[0.92rem] mb-6">
        Every feeling is reviewed here before it can appear on the public wall.
      </p>

      {/* tabs */}
      <div role="tablist" aria-label="Submission status" className="flex flex-wrap gap-2 mb-6">
        {TABS.map(t => (
          <button
            key={t} role="tab" aria-selected={tab === t}
            onClick={() => { setTab(t); setPage(0) }}
            className={`rounded-full border px-4.5 py-2 text-[0.82rem] font-body tracking-wide transition-colors ${
              tab === t ? 'border-rose bg-rose text-ivory' : 'border-linec bg-card text-softink hover:border-rose/60'
            }`}
          >
            {t.charAt(0) + t.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      {!data ? (
        <RowSkeleton rows={5} />
      ) : data.items.length === 0 ? (
        <p className="font-body text-softink py-12 text-center">
          {tab === 'PENDING' ? 'Nothing waiting — the inbox is quiet. 🕊️' : `No ${tab.toLowerCase()} submissions.`}
        </p>
      ) : (
        <div className="flex flex-col gap-3">
          {data.items.map(f => (
            <article key={f.id} className="rounded-2xl bg-card border border-linec p-5 sm:p-6">
              <blockquote className="font-display text-[1.1rem] leading-[1.55] text-charcoal whitespace-pre-line">
                &ldquo;{f.content}&rdquo;
              </blockquote>
              <div className="font-body text-[0.78rem] text-faint mt-3 flex flex-wrap items-center gap-x-2.5 gap-y-1">
                <span className="text-rose">{f.categories?.name ?? '—'}</span>
                <span aria-hidden="true">·</span><span className="italic">{f.mood}</span>
                <span aria-hidden="true">·</span>
                <span>{f.is_anonymous ? '🕊️ Anonymous' : (f.name || 'Unnamed')}</span>
                {f.email && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-1 text-softink" title="Visible to admins only">
                      <Mail size={11} aria-hidden="true" /> {f.email}
                    </span>
                  </>
                )}
                <span aria-hidden="true">·</span><span>{fmt(f.created_at)}</span>
                <span aria-hidden="true">·</span><StatusPill status={f.status} />
              </div>
              <div className="mt-4 pt-3.5 border-t border-linec/70 flex flex-wrap gap-2">
                {f.status !== 'APPROVED' && (
                  <ActionBtn onClick={() => act(f.id, 'APPROVED', 'Approved — now on the wall ✨')} kind="approve">
                    <Check size={14} aria-hidden="true" /> Approve
                  </ActionBtn>
                )}
                {f.status !== 'REJECTED' && (
                  <ActionBtn onClick={() => act(f.id, 'REJECTED', 'Rejected')} kind="reject">
                    <XIcon size={14} aria-hidden="true" /> Reject
                  </ActionBtn>
                )}
                {f.status !== 'ARCHIVED' && (
                  <ActionBtn onClick={() => act(f.id, 'ARCHIVED', 'Archived')}>
                    <Archive size={14} aria-hidden="true" /> Archive
                  </ActionBtn>
                )}
              </div>
            </article>
          ))}
        </div>
      )}

      {data && totalPages > 1 && (
        <div className="flex items-center justify-center gap-4 mt-8 font-body text-[0.88rem] text-softink">
          <button disabled={page === 0} onClick={() => setPage(p => p - 1)} className="rounded-full border border-linec px-4 py-2 disabled:opacity-40 hover:border-rose transition-colors">← Prev</button>
          <span className="tabular-nums">Page {page + 1} of {totalPages}</span>
          <button disabled={page + 1 >= totalPages} onClick={() => setPage(p => p + 1)} className="rounded-full border border-linec px-4 py-2 disabled:opacity-40 hover:border-rose transition-colors">Next →</button>
        </div>
      )}
    </div>
  )
}

function ActionBtn({ children, onClick, kind }) {
  const cls = kind === 'approve'
    ? 'border-emerald-300 text-emerald-700 hover:bg-emerald-50'
    : kind === 'reject'
      ? 'border-rose/40 text-rosedeep hover:bg-roseveil'
      : 'border-linec text-softink hover:border-rose/50'
  return (
    <button onClick={onClick} className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-[0.82rem] font-body transition-colors ${cls}`}>
      {children}
    </button>
  )
}
