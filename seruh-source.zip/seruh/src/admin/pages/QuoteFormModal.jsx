import { useState } from 'react'
import { X } from 'lucide-react'
import { adminApi } from '../adminApi'
import { MOODS } from '../../data/quotes'
import { useUi } from '../../context/UiContext'

export default function QuoteFormModal({ quote, categories, onClose, onSaved }) {
  const { showToast } = useUi()
  const [busy, setBusy] = useState(false)
  const isNew = !quote

  const submit = async (e) => {
    e.preventDefault()
    const d = Object.fromEntries(new FormData(e.target).entries())
    const fields = {
      quote: d.quote.trim(),
      category_id: d.category_id,
      mood: d.mood,
      author: d.author.trim() || 'SeRuh',
      tags: d.tags.split(',').map(t => t.trim()).filter(Boolean),
      featured: d.featured === 'on',
      status: d.status,
    }
    if (fields.quote.length < 3) { showToast('The quote needs a few more words.'); return }
    setBusy(true)
    try {
      if (isNew) await adminApi.createQuote(fields)
      else await adminApi.updateQuote(quote.id, fields)
      showToast(isNew ? 'Feeling published to the collection ✨' : 'Quote updated')
      onSaved()
    } catch {
      showToast('Something went wrong. Please try again.')
      setBusy(false)
    }
  }

  const inputCls = 'w-full rounded-xl bg-ivory border border-linec px-4 py-2.5 text-[0.92rem] text-charcoal font-body focus:border-rose focus:outline-none focus:ring-2 focus:ring-rose/25'
  const labelCls = 'block font-body text-[0.8rem] font-medium text-softink mb-1.5'

  return (
    <div role="dialog" aria-modal="true" aria-label={isNew ? 'Add new feeling' : 'Edit quote'} className="fixed inset-0 z-[80] flex items-center justify-center p-4 overflow-y-auto">
      <div className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg rounded-2xl bg-card border border-linec p-7 sm:p-8 shadow-2xl my-8">
        <button onClick={onClose} aria-label="Close" className="absolute top-4 right-4 p-2 rounded-full text-softink hover:text-charcoal hover:bg-cream transition-colors">
          <X size={17} aria-hidden="true" />
        </button>
        <h2 className="font-display text-2xl text-charcoal mb-6">{isNew ? 'Add New Feeling' : 'Edit Quote'}</h2>

        <form onSubmit={submit} className="flex flex-col gap-4">
          <div>
            <label htmlFor="qf-quote" className={labelCls}>Quote</label>
            <textarea id="qf-quote" name="quote" required rows={4} defaultValue={quote?.quote ?? ''} className={`${inputCls} font-display text-[1.05rem] resize-y`} />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="qf-cat" className={labelCls}>Category</label>
              <select id="qf-cat" name="category_id" className={inputCls} defaultValue={quote?.category_id ?? categories[0]?.id}>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="qf-mood" className={labelCls}>Mood</label>
              <select id="qf-mood" name="mood" className={inputCls} defaultValue={quote?.mood ?? 'Emotional'}>
                {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="qf-author" className={labelCls}>Author / Source</label>
              <input id="qf-author" name="author" defaultValue={quote?.author ?? 'SeRuh'} className={inputCls} />
            </div>
            <div>
              <label htmlFor="qf-status" className={labelCls}>Status</label>
              <select id="qf-status" name="status" className={inputCls} defaultValue={quote?.status ?? 'PUBLISHED'}>
                <option value="PUBLISHED">Published</option>
                <option value="DRAFT">Draft</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="qf-tags" className={labelCls}>Tags <span className="text-faint font-normal">(comma separated)</span></label>
            <input id="qf-tags" name="tags" defaultValue={(quote?.tags ?? []).join(', ')} className={inputCls} placeholder="love, night, missing" />
          </div>
          <label className="flex items-center gap-3 font-body text-[0.9rem] text-softink rounded-xl bg-ivory border border-linec px-4 py-3 cursor-pointer">
            <input type="checkbox" name="featured" defaultChecked={quote?.featured ?? false} className="accent-rose w-4 h-4" />
            Featured — eligible for Today&rsquo;s Feeling
          </label>

          <button type="submit" disabled={busy} className="mt-1 rounded-full bg-charcoal text-ivory px-6 py-3.5 text-[0.92rem] hover:bg-rosedeep transition-colors disabled:opacity-60">
            {busy ? 'Saving…' : (isNew ? 'Publish Feeling' : 'Save changes')}
          </button>
        </form>
      </div>
    </div>
  )
}
