import { useEffect, useState } from 'react'
import { adminApi } from '../adminApi'
import { RowSkeleton } from '../../components/Skeleton'

const RANGES = [
  { key: 'today', label: 'Today', days: 1 },
  { key: '7d', label: 'Last 7 days', days: 7 },
  { key: '30d', label: 'Last 30 days', days: 30 },
  { key: '90d', label: 'Last 90 days', days: 90 },
]

const rangeDates = (days) => ({
  from: new Date(Date.now() - days * 86400_000).toISOString(),
  to: new Date().toISOString(),
})

const fmt = (n) => (n ?? 0).toLocaleString()

export default function Analytics() {
  const [range, setRange] = useState('7d')
  const [data, setData] = useState(null)      // { overview, top, cats, ai }
  const [sortBy, setSortBy] = useState('likes')
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    let alive = true
    setData(null); setFailed(false)
    const { from, to } = rangeDates(RANGES.find(r => r.key === range).days)
    Promise.all([
      adminApi.analyticsOverview(from, to),
      adminApi.topQuotes(from, to, sortBy, 8),
      adminApi.categoryStats(from, to),
      adminApi.aiStats(from, to),
    ]).then(([overview, top, cats, ai]) => {
      if (alive) setData({ overview, top, cats, ai })
    }).catch(() => { if (alive) setFailed(true) })
    return () => { alive = false }
  }, [range, sortBy])

  return (
    <div>
      <h1 className="font-display text-3xl text-charcoal mb-2">SeRuh Analytics</h1>
      <p className="font-body text-softink text-[0.92rem] mb-6">Aggregated trends only — no private feelings are shown here.</p>

      {/* time filter */}
      <div role="group" aria-label="Time range" className="flex flex-wrap gap-2 mb-8">
        {RANGES.map(r => (
          <button key={r.key} onClick={() => setRange(r.key)} aria-pressed={range === r.key}
            className={`rounded-full border px-4 py-2 text-[0.82rem] font-body transition-colors ${
              range === r.key ? 'border-rose bg-rose text-ivory' : 'border-linec bg-card text-softink hover:border-rose/60'
            }`}>
            {r.label}
          </button>
        ))}
      </div>

      {failed ? (
        <p className="font-body text-softink py-10">Couldn&rsquo;t load analytics. Please refresh.</p>
      ) : !data ? (
        <RowSkeleton rows={6} />
      ) : (
        <Body data={data} sortBy={sortBy} setSortBy={setSortBy} />
      )}
    </div>
  )
}

function Body({ data, sortBy, setSortBy }) {
  const o = data.overview ?? {}
  const noData = (o.active_visitors ?? 0) === 0 && (o.likes_period ?? 0) === 0 && (o.ai_period ?? 0) === 0

  const tiles = [
    ['Total Users', o.total_users], ['New Users', o.new_users], ['Active Visitors', o.active_visitors],
    ['Total Quotes', o.total_quotes], ['Likes (period)', o.likes_period], ['Saves (period)', o.saves_period],
    ['Feelings Total', o.total_feelings], ['Approved', o.approved_feelings], ['Pending', o.pending_feelings],
    ['AI Generations', o.ai_period], ['AI Failed', o.ai_failed_period], ['AI Avg Time', o.ai_avg_ms ? `${fmt(o.ai_avg_ms)} ms` : '—'],
  ]

  return (
    <div className="flex flex-col gap-10">
      {/* overview tiles */}
      <section aria-label="Overview">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {tiles.map(([label, val]) => (
            <div key={label} className="rounded-2xl bg-card border border-linec p-4.5">
              <p className="font-body text-[0.7rem] tracking-[0.12em] uppercase text-softink mb-1.5">{label}</p>
              <p className="font-display text-[1.7rem] text-charcoal tabular-nums leading-none">{typeof val === 'string' ? val : fmt(val)}</p>
            </div>
          ))}
        </div>
      </section>

      {noData && (
        <p className="font-body text-softink text-center py-4">Not enough data yet. Give SeRuh a little time. 🕊️</p>
      )}

      {/* category performance */}
      <section aria-label="Category performance">
        <h2 className="font-display text-xl text-charcoal mb-1">Explore by Feeling — what resonates</h2>
        <p className="font-body text-[0.8rem] text-faint mb-4">Likes per category in the selected period.</p>
        <BarList
          rows={(data.cats ?? []).map(c => ({ label: c.name, value: Number(c.likes) || 0, extra: `${fmt(c.saves)} saves · ${fmt(c.quotes)} quotes` }))}
        />
      </section>

      {/* top quotes */}
      <section aria-label="Quote performance">
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <h2 className="font-display text-xl text-charcoal">Most loved quotes</h2>
          <div role="group" aria-label="Sort by" className="flex gap-1.5 ml-auto">
            {['likes', 'saves'].map(k => (
              <button key={k} onClick={() => setSortBy(k)} aria-pressed={sortBy === k}
                className={`rounded-full border px-3.5 py-1.5 text-[0.78rem] font-body transition-colors ${sortBy === k ? 'border-rose bg-rose text-ivory' : 'border-linec bg-card text-softink hover:border-rose/60'}`}>
                By {k}
              </button>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto rounded-2xl border border-linec bg-card">
          <table className="w-full font-body text-[0.85rem]">
            <thead>
              <tr className="text-left text-softink border-b border-linec">
                <th className="px-5 py-3 font-medium">Quote</th>
                <th className="px-3 py-3 font-medium">Category</th>
                <th className="px-3 py-3 font-medium text-right">Likes</th>
                <th className="px-3 py-3 font-medium text-right">Saves</th>
                <th className="px-3 py-3 font-medium text-right">Shares</th>
                <th className="px-5 py-3 font-medium text-right">Copies</th>
              </tr>
            </thead>
            <tbody>
              {(data.top ?? []).map(q => (
                <tr key={q.id} className="border-b border-linec/60 last:border-0">
                  <td className="px-5 py-3 font-display text-[0.95rem] text-charcoal max-w-sm"><span className="line-clamp-1">{q.quote}</span></td>
                  <td className="px-3 py-3 text-rose whitespace-nowrap">{q.category}</td>
                  <td className="px-3 py-3 text-right tabular-nums text-charcoal">{fmt(q.likes)}</td>
                  <td className="px-3 py-3 text-right tabular-nums text-charcoal">{fmt(q.saves)}</td>
                  <td className="px-3 py-3 text-right tabular-nums text-charcoal">{fmt(q.shares)}</td>
                  <td className="px-5 py-3 text-right tabular-nums text-charcoal">{fmt(q.copies)}</td>
                </tr>
              ))}
              {(data.top ?? []).length === 0 && (
                <tr><td colSpan={6} className="px-5 py-6 text-center text-softink">Not enough data yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* AI usage */}
      <section aria-label="AI usage">
        <h2 className="font-display text-xl text-charcoal mb-1">AI Usage</h2>
        <p className="font-body text-[0.8rem] text-faint mb-4">
          {fmt(o.ai_period)} generations in period · {fmt(o.ai_guest_period)} by guests · {fmt(o.ai_user_period)} by members · {fmt(o.users_generated)} distinct members
        </p>
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <p className="font-body text-[0.78rem] font-medium text-softink mb-3">By mood</p>
            <BarList rows={(data.ai?.by_mood ?? []).map(m => ({ label: m.mood, value: Number(m.n) }))} />
          </div>
          <div>
            <p className="font-body text-[0.78rem] font-medium text-softink mb-3">By style</p>
            <BarList rows={(data.ai?.by_style ?? []).map(m => ({ label: m.style, value: Number(m.n) }))} />
          </div>
        </div>
        <DayStrip days={data.ai?.by_day ?? []} />
      </section>

      {/* user trends */}
      <section aria-label="User trends">
        <h2 className="font-display text-xl text-charcoal mb-3">Members</h2>
        <p className="font-body text-[0.9rem] text-softink">
          {fmt(o.total_users)} total · {fmt(o.new_users)} joined in period · {fmt(o.users_saved)} saved quotes · {fmt(o.users_submitted)} shared feelings
        </p>
      </section>
    </div>
  )
}

/* Single-measure horizontal bars — one hue (rose), labels in ink. */
function BarList({ rows }) {
  const max = Math.max(1, ...rows.map(r => r.value))
  if (rows.length === 0 || rows.every(r => r.value === 0)) {
    return <p className="font-body text-[0.85rem] text-softink py-3">Not enough data yet. Give SeRuh a little time.</p>
  }
  return (
    <div className="flex flex-col gap-2.5">
      {rows.map(r => (
        <div key={r.label} className="grid grid-cols-[8.5rem_1fr_auto] items-center gap-3" title={r.extra ?? ''}>
          <span className="font-body text-[0.82rem] text-charcoal truncate">{r.label}</span>
          <div className="h-3.5 rounded-r-[4px] bg-cream relative overflow-hidden" role="img" aria-label={`${r.label}: ${r.value}`}>
            <div className="absolute inset-y-0 left-0 rounded-r-[4px] bg-rose" style={{ width: `${Math.max(2, (r.value / max) * 100)}%` }} />
          </div>
          <span className="font-body text-[0.8rem] text-softink tabular-nums w-10 text-right">{r.value.toLocaleString()}</span>
        </div>
      ))}
    </div>
  )
}

/* Generations per day — thin vertical bars, single hue. */
function DayStrip({ days }) {
  if (!days.length) return null
  const max = Math.max(1, ...days.map(d => Number(d.n)))
  return (
    <div className="mt-7">
      <p className="font-body text-[0.78rem] font-medium text-softink mb-3">Generations per day</p>
      <div className="flex items-end gap-1 h-24 rounded-xl border border-linec bg-card p-3 overflow-x-auto">
        {days.map(d => (
          <div key={d.day} className="flex flex-col items-center gap-1 min-w-5" title={`${d.day}: ${d.n}`}>
            <div className="w-3 rounded-t-[4px] bg-rose" style={{ height: `${Math.max(4, (Number(d.n) / max) * 72)}px` }}
              role="img" aria-label={`${d.day}: ${d.n} generations`} />
            <span className="font-body text-[0.55rem] text-faint tabular-nums">{d.day.slice(8)}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
