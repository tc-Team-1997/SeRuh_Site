import { useCallback, useEffect, useState } from 'react'
import { Plus, Star, Pencil, Trash2, Archive, ArchiveRestore, Eye, EyeOff } from 'lucide-react'
import { adminApi } from '../adminApi'
import { useUi } from '../../context/UiContext'
import { RowSkeleton } from '../../components/Skeleton'
import QuoteFormModal from './QuoteFormModal'

const STATUSES = ['PUBLISHED', 'DRAFT', 'ARCHIVED']

export default function QuotesAdmin() {
  const { showToast } = useUi()
  const [cats, setCats] = useState([])
  const [filters, setFilters] = useState({ status: '', categoryId: '', featured: '', search: '' })
  const [page, setPage] = useState(0)
  const [data, setData] = useState(null)
  const [editing, setEditing] = useState(undefined) // undefined=closed, null=new, object=edit
  const [confirmDelete, setConfirmDelete] = useState(null)

  useEffect(() => { adminApi.listCategories().then(setCats).catch(() => {}) }, [])

  const load = useCallback(() => {
    setData(null)
    adminApi.listQuotes({
      page,
      status: filters.status || null,
      categoryId: filters.categoryId || null,
      featured: filters.featured === '' ? null : filters.featured === 'yes',
      search: filters.search,
    }).then(setData).catch(() => showToast('Something went wrong. Please try again.'))
  }, [page, filters, showToast])

  useEffect(() => { load() }, [load])

  const patch = async (id, p, msg) => {
    try { await adminApi.updateQuote(id, p); showToast(msg); load() }
    catch { showToast('Something went wrong. Please try again.') }
  }

  const doDelete = async (id) => {
    setConfirmDelete(null)
    try { await adminApi.deleteQuote(id); showToast('Quote deleted'); load() }
    catch { showToast('Something went wrong. Please try again.') }
  }

  const selCls = 'rounded-xl bg-card border border-linec px-3 py-2 text-[0.85rem] text-charcoal font-body focus:border-rose focus:outline-none'
  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4 mb-2">
        <h1 className="font-display text-3xl text-charcoal">Manage Quotes</h1>
        <button
          onClick={() => setEditing(null)}
          className="inline-flex items-center gap-2 rounded-full bg-charcoal text-ivory px-5 py-2.5 text-[0.88rem] hover:bg-rosedeep transition-colors"
        >
          <Plus size={15} aria-hidden="true" /> Add New Feeling
        </button>
      </div>
      <p className="font-body text-softink text-[0.92rem] mb-6">{data ? `${data.total} quotes` : ' '}</p>

      {/* filters */}
      <div className="flex flex-wrap gap-2.5 mb-6">
        <input
          type="search" placeholder="Search quotes…" value={filters.search}
          onChange={e => { setFilters(f => ({ ...f, search: e.target.value })); setPage(0) }}
          className={`${selCls} w-56`} aria-label="Search quotes"
        />
        <select value={filters.status} onChange={e => { setFilters(f => ({ ...f, status: e.target.value })); setPage(0) }} className={selCls} aria-label="Filter by status">
          <option value="">All statuses</option>
          {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={filters.categoryId} onChange={e => { setFilters(f => ({ ...f, categoryId: e.target.value })); setPage(0) }} className={selCls} aria-label="Filter by category">
          <option value="">All categories</option>
          {cats.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select value={filters.featured} onChange={e => { setFilters(f => ({ ...f, featured: e.target.value })); setPage(0) }} className={selCls} aria-label="Filter by featured">
          <option value="">Featured + not</option>
          <option value="yes">Featured only</option>
          <option value="no">Not featured</option>
        </select>
      </div>

      {!data ? (
        <RowSkeleton rows={6} />
      ) : data.items.length === 0 ? (
        <p className="font-body text-softink py-10 text-center">No quotes match these filters.</p>
      ) : (
        <div className="flex flex-col gap-3">
          {data.items.map(q => (
            <div key={q.id} className="rounded-2xl bg-card border border-linec p-5 flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex-1 min-w-0">
                <p className="font-display text-[1.05rem] text-charcoal leading-snug line-clamp-2 whitespace-pre-line">{q.quote}</p>
                <p className="font-body text-[0.75rem] text-faint mt-1.5">
                  <span className="text-rose">{q.categories?.name ?? '—'}</span> · {q.mood}
                  {q.author ? <> · {q.author}</> : null} · <StatusPill status={q.status} />
                  {q.featured && <span className="ml-1.5 text-gold">★ featured</span>}
                </p>
              </div>
              <div className="flex items-center gap-1 shrink-0 flex-wrap">
                <IconBtn title={q.featured ? 'Unfeature' : 'Mark as featured'} onClick={() => patch(q.id, { featured: !q.featured }, q.featured ? 'Removed from featured' : 'Marked as featured ★')}>
                  <Star size={16} className={q.featured ? 'fill-gold text-gold' : ''} aria-hidden="true" />
                </IconBtn>
                {q.status === 'PUBLISHED'
                  ? <IconBtn title="Unpublish (draft)" onClick={() => patch(q.id, { status: 'DRAFT' }, 'Moved to drafts')}><EyeOff size={16} aria-hidden="true" /></IconBtn>
                  : <IconBtn title="Publish" onClick={() => patch(q.id, { status: 'PUBLISHED' }, 'Published')}><Eye size={16} aria-hidden="true" /></IconBtn>}
                {q.status === 'ARCHIVED'
                  ? <IconBtn title="Restore" onClick={() => patch(q.id, { status: 'DRAFT' }, 'Restored to drafts')}><ArchiveRestore size={16} aria-hidden="true" /></IconBtn>
                  : <IconBtn title="Archive" onClick={() => patch(q.id, { status: 'ARCHIVED' }, 'Archived')}><Archive size={16} aria-hidden="true" /></IconBtn>}
                <IconBtn title="Edit" onClick={() => setEditing(q)}><Pencil size={16} aria-hidden="true" /></IconBtn>
                <IconBtn title="Delete" danger onClick={() => setConfirmDelete(q)}><Trash2 size={16} aria-hidden="true" /></IconBtn>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* pagination */}
      {data && totalPages > 1 && (
        <div className="flex items-center justify-center gap-4 mt-8 font-body text-[0.88rem] text-softink">
          <button disabled={page === 0} onClick={() => setPage(p => p - 1)} className="rounded-full border border-linec px-4 py-2 disabled:opacity-40 hover:border-rose transition-colors">← Prev</button>
          <span className="tabular-nums">Page {page + 1} of {totalPages}</span>
          <button disabled={page + 1 >= totalPages} onClick={() => setPage(p => p + 1)} className="rounded-full border border-linec px-4 py-2 disabled:opacity-40 hover:border-rose transition-colors">Next →</button>
        </div>
      )}

      {/* create/edit modal */}
      {editing !== undefined && (
        <QuoteFormModal
          quote={editing}
          categories={cats}
          onClose={() => setEditing(undefined)}
          onSaved={() => { setEditing(undefined); load() }}
        />
      )}

      {/* delete confirmation */}
      {confirmDelete && (
        <div role="dialog" aria-modal="true" aria-label="Confirm deletion" className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm" onClick={() => setConfirmDelete(null)} />
          <div className="relative w-full max-w-sm rounded-2xl bg-card border border-linec p-7 shadow-2xl">
            <p className="font-display text-xl text-charcoal mb-2">Delete this quote forever?</p>
            <p className="font-body text-[0.88rem] text-softink line-clamp-2 mb-6">&ldquo;{confirmDelete.quote}&rdquo;</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setConfirmDelete(null)} className="rounded-full border border-linec px-5 py-2.5 text-[0.85rem] text-softink hover:border-rose transition-colors">Keep it</button>
              <button onClick={() => doDelete(confirmDelete.id)} className="rounded-full bg-rosedeep text-ivory px-5 py-2.5 text-[0.85rem] hover:brightness-110 transition-all">Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function IconBtn({ children, title, onClick, danger }) {
  return (
    <button
      onClick={onClick} title={title} aria-label={title}
      className={`p-2.5 rounded-full transition-colors ${danger ? 'text-softink hover:text-ivory hover:bg-rosedeep' : 'text-softink hover:text-rosedeep hover:bg-roseveil/70'}`}
    >
      {children}
    </button>
  )
}

export function StatusPill({ status }) {
  const map = {
    PUBLISHED: 'text-emerald-700 bg-emerald-50 border-emerald-200',
    DRAFT: 'text-softink bg-cream border-linec',
    ARCHIVED: 'text-faint bg-cream border-linec',
    PENDING: 'text-amber-700 bg-amber-50 border-amber-200',
    APPROVED: 'text-emerald-700 bg-emerald-50 border-emerald-200',
    REJECTED: 'text-rosedeep bg-roseveil border-rose/30',
  }
  return (
    <span className={`inline-block align-middle rounded-full border px-2 py-0.5 text-[0.68rem] tracking-wide ${map[status] ?? map.DRAFT}`}>
      {status}
    </span>
  )
}
