import { useEffect, useState } from 'react'
import { isBackendConfigured } from '../lib/config'
import { adminApi } from './adminApi'
import AdminLogin from './AdminLogin'
import AdminShell from './AdminShell'

export default function AdminApp() {
  if (!isBackendConfigured) return <NotConnected />
  return <AdminAuthGate />
}

function AdminAuthGate() {
  const [state, setState] = useState('checking') // checking | login | ready

  useEffect(() => {
    let alive = true
    ;(async () => {
      const session = await adminApi.getSession()
      if (!alive) return
      if (!session) { setState('login'); return }
      const ok = await adminApi.amIAdmin()
      if (!alive) return
      if (!ok) { await adminApi.signOut(); setState('login'); return }
      setState('ready')
    })()
    const { data: sub } = adminApi.onAuthChange(session => {
      if (!session) setState('login')
    })
    return () => { alive = false; sub?.subscription?.unsubscribe?.() }
  }, [])

  if (state === 'checking') {
    return (
      <div className="min-h-svh bg-ivory flex items-center justify-center">
        <p className="font-display italic text-xl text-softink">Opening the quiet room…</p>
      </div>
    )
  }
  if (state === 'login') return <AdminLogin onSuccess={() => setState('ready')} />
  return <AdminShell onSignOut={async () => { await adminApi.signOut() }} />
}

function NotConnected() {
  return (
    <div className="min-h-svh bg-ivory flex items-center justify-center px-6">
      <div className="max-w-md text-center">
        <p className="font-display text-3xl text-charcoal mb-4">
          Se<span className="text-rose">Ruh</span> Admin
        </p>
        <p className="font-body text-softink leading-relaxed mb-6">
          The admin dashboard needs the database backend, which isn&rsquo;t connected in this build yet.
          Once the Supabase project is set up and its keys are added, this page becomes the
          secure login for managing quotes, submissions and categories.
        </p>
        <a href="#home" onClick={() => setTimeout(() => location.reload(), 50)} className="inline-block rounded-full border border-linec px-6 py-2.5 text-[0.88rem] text-softink hover:border-rose hover:text-rosedeep transition-colors">
          ← Back to SeRuh
        </a>
      </div>
    </div>
  )
}
