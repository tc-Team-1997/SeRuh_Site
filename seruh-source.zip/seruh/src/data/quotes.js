// ─────────────────────────────────────────────────────────────
// SeRuh quote data — kept fully separate from UI components.
// In a future phase this module can be swapped for an API,
// database, CMS or admin dashboard without touching the frontend.
// ─────────────────────────────────────────────────────────────

import {
  Heart, Moon, HeartHandshake, Flower2, Feather,
  Bird, Sunrise, Mail, BookOpen, Coffee, Sparkles,
} from 'lucide-react'

export const CATEGORIES = [
  { key: 'Love',              label: 'Love',              icon: Heart },
  { key: 'Midnight Thoughts', label: 'Midnight Thoughts', icon: Moon },
  { key: 'Friendship',        label: 'Friendship',        icon: HeartHandshake },
  { key: 'Life',              label: 'Life',              icon: Flower2 },
  { key: 'Heartfelt',         label: 'Heartfelt',         icon: Feather },
  { key: 'Healing',           label: 'Healing',           icon: Bird },
  { key: 'Hope',              label: 'Hope',              icon: Sunrise },
  { key: 'Unsaid Things',     label: 'Unsaid Things',     icon: Mail },
  { key: 'Memories',          label: 'Memories',          icon: BookOpen },
  { key: 'Random Thoughts',   label: 'Random Thoughts',   icon: Coffee },
]

/** Icon for a category name (works for admin-created categories too). */
export function iconForCategory(name) {
  return CATEGORIES.find(c => c.key === name)?.icon ?? Sparkles
}

export const MOODS = [
  'Happy', 'Romantic', 'Peaceful', 'Sad', 'Hopeful',
  'Nostalgic', 'Emotional', 'Thoughtful', 'Lonely', 'Grateful',
]

export const QUOTES = [
  // ── Love ──────────────────────────────────────────────
  { id: 1,  quote: 'Loving you was never loud.\nIt was the quietest thing I ever did\nwith my whole heart.', category: 'Love', mood: 'Romantic', author: 'SeRuh', tags: ['love', 'quiet', 'devotion'], featured: false },
  { id: 2,  quote: 'Some people touch your life like light through a window — softly, and everywhere at once.', category: 'Love', mood: 'Grateful', author: 'SeRuh', tags: ['love', 'light', 'presence'], featured: false },
  { id: 3,  quote: 'You are my favourite thought to return to.', category: 'Love', mood: 'Romantic', author: 'SeRuh', tags: ['love', 'thoughts', 'home'], featured: false },
  { id: 4,  quote: 'I never learned the language you loved in — but I answered anyway, every time.', category: 'Love', mood: 'Emotional', author: 'SeRuh', tags: ['love', 'language', 'understanding'], featured: false },

  // ── Midnight Thoughts ─────────────────────────────────
  { id: 5,  quote: 'Not every silence is empty.', category: 'Midnight Thoughts', mood: 'Thoughtful', author: 'SeRuh', tags: ['silence', 'night', 'depth'], featured: true },
  { id: 6,  quote: "3 a.m. doesn't ask questions.\nIt just sits with you while you remember.", category: 'Midnight Thoughts', mood: 'Lonely', author: 'SeRuh', tags: ['night', 'memories', 'missing'], featured: false },
  { id: 7,  quote: 'The night knows every version of me the day has never met.', category: 'Midnight Thoughts', mood: 'Thoughtful', author: 'SeRuh', tags: ['night', 'identity', 'hidden'], featured: false },
  { id: 8,  quote: 'Some thoughts only surface when the world stops watching.', category: 'Midnight Thoughts', mood: 'Peaceful', author: 'SeRuh', tags: ['night', 'thoughts', 'solitude'], featured: false },

  // ── Friendship ────────────────────────────────────────
  { id: 9,  quote: 'The best friendships are the ones where silence feels like conversation.', category: 'Friendship', mood: 'Peaceful', author: 'SeRuh', tags: ['friendship', 'silence', 'comfort'], featured: false },
  { id: 10, quote: "You didn't fix anything.\nYou just stayed.\nThat was everything.", category: 'Friendship', mood: 'Grateful', author: 'SeRuh', tags: ['friendship', 'staying', 'support'], featured: false },
  { id: 11, quote: 'Old friends are proof that some chapters never really close.', category: 'Friendship', mood: 'Nostalgic', author: 'SeRuh', tags: ['friendship', 'time', 'chapters'], featured: false },

  // ── Life ──────────────────────────────────────────────
  { id: 12, quote: 'Life rarely announces its important days.\nThey arrive dressed as ordinary ones.', category: 'Life', mood: 'Thoughtful', author: 'SeRuh', tags: ['life', 'moments', 'ordinary'], featured: false },
  { id: 13, quote: 'We spend years learning to be someone — and the rest, learning to be ourselves.', category: 'Life', mood: 'Thoughtful', author: 'SeRuh', tags: ['life', 'self', 'growth'], featured: false },
  { id: 14, quote: 'Growing up is realising the small moments were the big ones.', category: 'Life', mood: 'Nostalgic', author: 'SeRuh', tags: ['life', 'growing', 'moments'], featured: false },
  { id: 15, quote: 'You are allowed to outgrow the life you once prayed for.', category: 'Life', mood: 'Hopeful', author: 'SeRuh', tags: ['life', 'growth', 'permission'], featured: false },

  // ── Heartfelt ─────────────────────────────────────────
  { id: 16, quote: 'Some feelings stay quiet,\nnot because they are small,\nbut because they are too deep for words.', category: 'Heartfelt', mood: 'Emotional', author: 'SeRuh', tags: ['feelings', 'depth', 'quiet'], featured: true },
  { id: 17, quote: 'I carry conversations we never had,\nand somehow, they still hurt.', category: 'Heartfelt', mood: 'Sad', author: 'SeRuh', tags: ['unsaid', 'missing', 'ache'], featured: false },
  { id: 18, quote: 'The heart keeps a guest room ready for people who are never coming back.', category: 'Heartfelt', mood: 'Lonely', author: 'SeRuh', tags: ['missing', 'longing', 'heart'], featured: false },

  // ── Healing ───────────────────────────────────────────
  { id: 19, quote: 'Healing is not forgetting.\nIt is remembering without drowning.', category: 'Healing', mood: 'Hopeful', author: 'SeRuh', tags: ['healing', 'memory', 'strength'], featured: false },
  { id: 20, quote: 'One day the ache became a scar,\nand the scar became a story I could finally tell.', category: 'Healing', mood: 'Emotional', author: 'SeRuh', tags: ['healing', 'scars', 'stories'], featured: false },
  { id: 21, quote: 'Be gentle with yourself — you are still learning to live with what you survived.', category: 'Healing', mood: 'Peaceful', author: 'SeRuh', tags: ['healing', 'gentleness', 'self'], featured: false },
  { id: 22, quote: 'Some wounds close faster when you stop asking them to explain themselves.', category: 'Healing', mood: 'Thoughtful', author: 'SeRuh', tags: ['healing', 'acceptance', 'wounds'], featured: false },

  // ── Hope ──────────────────────────────────────────────
  { id: 23, quote: 'Even the longest night keeps a little dawn in its pocket.', category: 'Hope', mood: 'Hopeful', author: 'SeRuh', tags: ['hope', 'night', 'dawn'], featured: false },
  { id: 24, quote: 'Hope is the quietest voice in the room — and somehow the last one standing.', category: 'Hope', mood: 'Hopeful', author: 'SeRuh', tags: ['hope', 'quiet', 'strength'], featured: false },
  { id: 25, quote: 'Begin again.\nSoftly counts.', category: 'Hope', mood: 'Peaceful', author: 'SeRuh', tags: ['hope', 'beginnings', 'gentle'], featured: false },

  // ── Unsaid Things ─────────────────────────────────────
  { id: 26, quote: 'The heaviest words are the ones we swallow.', category: 'Unsaid Things', mood: 'Emotional', author: 'SeRuh', tags: ['unsaid', 'words', 'weight'], featured: false },
  { id: 27, quote: 'I wrote you a hundred letters.\nThe paper never knew.', category: 'Unsaid Things', mood: 'Lonely', author: 'SeRuh', tags: ['unsaid', 'letters', 'missing'], featured: false },
  { id: 28, quote: 'Between what I said and what I meant, there is a whole unlived life.', category: 'Unsaid Things', mood: 'Thoughtful', author: 'SeRuh', tags: ['unsaid', 'meaning', 'distance'], featured: false },
  { id: 29, quote: 'Some goodbyes happen in complete sentences no one ever speaks.', category: 'Unsaid Things', mood: 'Sad', author: 'SeRuh', tags: ['unsaid', 'goodbye', 'silence'], featured: false },

  // ── Memories ──────────────────────────────────────────
  { id: 30, quote: 'Memory is the only place where nothing ever has to end.', category: 'Memories', mood: 'Nostalgic', author: 'SeRuh', tags: ['memories', 'time', 'forever'], featured: false },
  { id: 31, quote: 'Some songs are time machines wearing melodies.', category: 'Memories', mood: 'Nostalgic', author: 'SeRuh', tags: ['memories', 'music', 'time'], featured: false },
  { id: 32, quote: 'We never really leave the places that made us.\nWe just visit them less.', category: 'Memories', mood: 'Nostalgic', author: 'SeRuh', tags: ['memories', 'places', 'belonging'], featured: false },

  // ── Random Thoughts ───────────────────────────────────
  { id: 33, quote: 'Maybe the pause between two thoughts is where we actually live.', category: 'Random Thoughts', mood: 'Thoughtful', author: 'SeRuh', tags: ['thoughts', 'pause', 'presence'], featured: false },
  { id: 34, quote: 'Chai always tastes better when someone else remembers how you take it.', category: 'Random Thoughts', mood: 'Happy', author: 'SeRuh', tags: ['chai', 'care', 'small joys'], featured: false },
  { id: 35, quote: 'Rain is just the sky thinking out loud.', category: 'Random Thoughts', mood: 'Peaceful', author: 'SeRuh', tags: ['rain', 'sky', 'thoughts'], featured: false },
  { id: 36, quote: 'Half of growing older is missing versions of people who still exist.', category: 'Random Thoughts', mood: 'Nostalgic', author: 'SeRuh', tags: ['missing', 'time', 'people'], featured: false },
]

/** Pick a random quote, avoiding the one currently shown. */
export function randomQuote(excludeId) {
  const pool = QUOTES.filter(q => q.id !== excludeId)
  return pool[Math.floor(Math.random() * pool.length)]
}
