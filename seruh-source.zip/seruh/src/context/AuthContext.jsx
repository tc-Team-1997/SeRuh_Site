import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { auth } from '../services/auth'
import { api } from '../services/api'

const AuthContext = createContext(null)
export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)          // { id, email, name, onboarding }
  const [ready, setReady] = useState(!auth.available)
  const [authVersion, setAuthVersion] = useState(0)
  const [wantAuthModal, setWantAuthModal] = useState(false) // open login/signup UI
  const merged = useRef(false)

  const refreshProfile = useCallback(async () => {
    try {
      const p = await auth.getProfile()
      setUser(p)
      return p
    } catch { return null }
  }, [])

  useEffect(() => {
    if (!auth.available) return
    let alive = true
    ;(async () => {
      const session = await auth.getSession()
      if (!alive) return
      if (session) await refreshProfile()
      setReady(true)
    })()
    const off = auth.onAuth(async (session) => {
      if (session) {
        // bring the guest's local likes/saves into the account, never delete them
        if (!merged.current) {
          merged.current = true
          try { await auth.mergeVisitorData() } catch { /* soft */ }
        }
        await refreshProfile()
      } else {
        merged.current = false
        setUser(null)
      }
      setAuthVersion(v => v + 1)
    })
    return () => { alive = false; off() }
  }, [refreshProfile])

  const signOut = useCallback(async () => {
    api.track?.('logout')
    await auth.signOut()
    setUser(null)
    setAuthVersion(v => v + 1)
  }, [])

  return (
    <AuthContext.Provider value={{
      user, ready, authVersion,
      available: auth.available,
      refreshProfile, signOut,
      wantAuthModal, openAuth: () => setWantAuthModal(true), closeAuth: () => setWantAuthModal(false),
    }}>
      {children}
    </AuthContext.Provider>
  )
}
