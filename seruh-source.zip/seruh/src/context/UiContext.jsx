import { createContext, useCallback, useContext, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X, MessageCircle, Link2, Copy } from 'lucide-react'
import { api } from '../services/api'

const UiContext = createContext(null)
export const useUi = () => useContext(UiContext)

/* Copy helper with a fallback for older browsers */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    try {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
      return true
    } catch {
      return false
    }
  }
}

export function UiProvider({ children }) {
  const [toast, setToast] = useState(null)
  const [shareQuote, setShareQuote] = useState(null)
  const timer = useRef(null)

  const showToast = useCallback((message) => {
    setToast({ id: Date.now(), message })
    clearTimeout(timer.current)
    timer.current = setTimeout(() => setToast(null), 2600)
  }, [])

  const copyQuote = useCallback(async (q) => {
    const ok = await copyText(`${q.quote}\n\n— SeRuh`)
    if (q?.id) api.track?.('quote_copy', 'quote', q.id)
    showToast(ok ? 'Copied to your heart… ✨' : "Couldn't copy — please select the text.")
  }, [showToast])

  const openShare = useCallback(async (q) => {
    if (q?.id) api.track?.('quote_share', 'quote', q.id)
    const text = `${q.quote}\n\n— SeRuh · Where Feelings Find Words`
    if (navigator.share) {
      try {
        await navigator.share({ title: 'SeRuh', text, url: window.location.href })
        return
      } catch (err) {
        if (err && err.name === 'AbortError') return
      }
    }
    setShareQuote(q)
  }, [])

  const waLink = shareQuote
    ? `https://wa.me/?text=${encodeURIComponent(`${shareQuote.quote}\n\n— SeRuh · ${window.location.href}`)}`
    : '#'

  return (
    <UiContext.Provider value={{ showToast, copyQuote, openShare }}>
      {children}

      {/* ── Share fallback sheet ───────────────────────── */}
      <AnimatePresence>
        {shareQuote && (
          <motion.div
            className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center p-4"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            role="dialog" aria-modal="true" aria-label="Share this feeling"
          >
            <div className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm" onClick={() => setShareQuote(null)} />
            <motion.div
              initial={{ opacity: 0, y: 26, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.98 }}
              transition={{ type: 'spring', stiffness: 320, damping: 30 }}
              className="relative w-full max-w-md rounded-2xl bg-card border border-linec shadow-2xl shadow-charcoal/10 p-7"
            >
              <button
                onClick={() => setShareQuote(null)}
                aria-label="Close share options"
                className="absolute top-4 right-4 p-2 rounded-full text-softink hover:text-charcoal hover:bg-cream transition-colors"
              >
                <X size={17} aria-hidden="true" />
              </button>
              <p className="font-body text-[11px] tracking-[0.22em] uppercase text-gold mb-3">Share this feeling</p>
              <p className="font-display text-xl leading-relaxed text-charcoal whitespace-pre-line mb-6">
                {shareQuote.quote}
              </p>
              <div className="flex flex-col gap-2.5">
                <a
                  href={waLink} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-3 rounded-xl border border-linec px-4 py-3 text-sm text-charcoal hover:border-rose hover:text-rosedeep transition-colors"
                >
                  <MessageCircle size={17} className="text-rose" aria-hidden="true" /> Share on WhatsApp
                </a>
                <button
                  onClick={async () => { await copyText(`${shareQuote.quote}\n\n— SeRuh · ${window.location.href}`); setShareQuote(null); showToast('Copied with link ✨') }}
                  className="flex items-center gap-3 rounded-xl border border-linec px-4 py-3 text-sm text-charcoal hover:border-rose hover:text-rosedeep transition-colors text-left"
                >
                  <Link2 size={17} className="text-rose" aria-hidden="true" /> Copy quote + link
                </button>
                <button
                  onClick={async () => { await copyText(`${shareQuote.quote}\n\n— SeRuh`); setShareQuote(null); showToast('Copied to your heart… ✨') }}
                  className="flex items-center gap-3 rounded-xl border border-linec px-4 py-3 text-sm text-charcoal hover:border-rose hover:text-rosedeep transition-colors text-left"
                >
                  <Copy size={17} className="text-rose" aria-hidden="true" /> Copy quote only
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Toast ──────────────────────────────────────── */}
      <div aria-live="polite" className="pointer-events-none fixed bottom-6 left-0 right-0 z-[100] flex justify-center px-4">
        <AnimatePresence>
          {toast && (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 16, filter: 'blur(4px)' }}
              animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
              exit={{ opacity: 0, y: 10, filter: 'blur(4px)' }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="rounded-full bg-charcoal text-ivory text-sm px-5 py-2.5 shadow-lg shadow-charcoal/20 font-body"
            >
              {toast.message}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </UiContext.Provider>
  )
}
