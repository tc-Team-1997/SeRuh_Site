import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { api } from '../services/api'
import { useUi } from './UiContext'
import { useAuth } from './AuthContext'

const DataContext = createContext(null)
export const useData = () => useContext(DataContext)

const GENERIC_ERROR = 'Something went wrong. Please try again.'

export function DataProvider({ children }) {
  const { showToast } = useUi()
  const { authVersion } = useAuth() ?? { authVersion: 0 }

  const [categories, setCategories] = useState([])
  const [likedQuotes, setLikedQuotes] = useState(() => new Set())
  const [likedFeelings, setLikedFeelings] = useState(() => new Set())
  const [savedMap, setSavedMap] = useState(() => new Map()) // quoteId -> saved_at
  const [counts, setCounts] = useState({})                  // quoteId -> like_count override
  const [feelingCounts, setFeelingCounts] = useState({})    // feelingId -> like_count override
  const [savedVersion, setSavedVersion] = useState(0)       // bump to refresh saved list
  const pending = useRef(new Set())                         // in-flight toggles (duplicate-click guard)

  useEffect(() => {
    let alive = true
    api.getCategories()
      .then(c => { if (alive) setCategories(c) })
      .catch(() => {})
    api.getMyActivity()
      .then(a => {
        if (!alive || !a) return
        setLikedQuotes(new Set(a.liked_quote_ids ?? []))
        setLikedFeelings(new Set(a.liked_feeling_ids ?? []))
        setSavedMap(new Map((a.saved ?? []).map(s => [s.quote_id, s.saved_at])))
      })
      .catch(() => {})
    return () => { alive = false }
  }, [authVersion])

  const toggleQuoteLike = useCallback(async (quote) => {
    const key = `ql:${quote.id}`
    if (pending.current.has(key)) return
    pending.current.add(key)

    const wasLiked = likedQuotes.has(quote.id)
    const baseCount = counts[quote.id] ?? quote.like_count ?? 0

    // optimistic
    setLikedQuotes(prev => { const n = new Set(prev); wasLiked ? n.delete(quote.id) : n.add(quote.id); return n })
    setCounts(prev => ({ ...prev, [quote.id]: Math.max(0, baseCount + (wasLiked ? -1 : 1)) }))

    try {
      const res = await api.toggleQuoteLike(quote.id)
      setLikedQuotes(prev => { const n = new Set(prev); res.liked ? n.add(quote.id) : n.delete(quote.id); return n })
      setCounts(prev => ({ ...prev, [quote.id]: res.count }))
      api.track?.(res.liked ? 'quote_like' : 'quote_unlike', 'quote', quote.id)
      if (res.liked) showToast('Kept close ❤️')
    } catch {
      // rollback
      setLikedQuotes(prev => { const n = new Set(prev); wasLiked ? n.add(quote.id) : n.delete(quote.id); return n })
      setCounts(prev => ({ ...prev, [quote.id]: baseCount }))
      showToast(GENERIC_ERROR)
    } finally {
      pending.current.delete(key)
    }
  }, [likedQuotes, counts, showToast])

  const toggleQuoteSave = useCallback(async (quote) => {
    const key = `qs:${quote.id}`
    if (pending.current.has(key)) return
    pending.current.add(key)

    const wasSaved = savedMap.has(quote.id)
    setSavedMap(prev => {
      const n = new Map(prev)
      wasSaved ? n.delete(quote.id) : n.set(quote.id, new Date().toISOString())
      return n
    })

    try {
      const res = await api.toggleQuoteSave(quote.id)
      setSavedMap(prev => {
        const n = new Map(prev)
        if (res.saved) { if (!n.has(quote.id)) n.set(quote.id, new Date().toISOString()) }
        else n.delete(quote.id)
        return n
      })
      setSavedVersion(v => v + 1)
      api.track?.(res.saved ? 'quote_save' : 'quote_unsave', 'quote', quote.id)
      showToast(res.saved ? 'Kept for later 🔖' : 'Removed from saved')
    } catch {
      setSavedMap(prev => {
        const n = new Map(prev)
        wasSaved ? n.set(quote.id, new Date().toISOString()) : n.delete(quote.id)
        return n
      })
      showToast(GENERIC_ERROR)
    } finally {
      pending.current.delete(key)
    }
  }, [savedMap, showToast])

  const toggleFeelingLike = useCallback(async (feeling) => {
    const key = `fl:${feeling.id}`
    if (pending.current.has(key)) return
    pending.current.add(key)

    const wasLiked = likedFeelings.has(feeling.id)
    const baseCount = feelingCounts[feeling.id] ?? feeling.like_count ?? 0
    setLikedFeelings(prev => { const n = new Set(prev); wasLiked ? n.delete(feeling.id) : n.add(feeling.id); return n })
    setFeelingCounts(prev => ({ ...prev, [feeling.id]: Math.max(0, baseCount + (wasLiked ? -1 : 1)) }))

    try {
      const res = await api.toggleFeelingLike(feeling.id)
      setLikedFeelings(prev => { const n = new Set(prev); res.liked ? n.add(feeling.id) : n.delete(feeling.id); return n })
      setFeelingCounts(prev => ({ ...prev, [feeling.id]: res.count }))
    } catch {
      setLikedFeelings(prev => { const n = new Set(prev); wasLiked ? n.add(feeling.id) : n.delete(feeling.id); return n })
      setFeelingCounts(prev => ({ ...prev, [feeling.id]: baseCount }))
      showToast(GENERIC_ERROR)
    } finally {
      pending.current.delete(key)
    }
  }, [likedFeelings, feelingCounts, showToast])

  const value = {
    categories,
    likedQuotes, savedMap, likedFeelings,
    counts, feelingCounts, savedVersion,
    toggleQuoteLike, toggleQuoteSave, toggleFeelingLike,
    likeCountOf: (q) => counts[q.id] ?? q.like_count ?? 0,
    feelingCountOf: (f) => feelingCounts[f.id] ?? f.like_count ?? 0,
  }

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}
