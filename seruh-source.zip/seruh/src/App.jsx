import { useEffect, useState } from 'react'
import { UiProvider } from './context/UiContext'
import { AuthProvider } from './context/AuthContext'
import { DataProvider } from './context/DataContext'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import TodaysFeeling from './components/TodaysFeeling'
import FeelingForYou from './components/FeelingForYou'
import AiGenerator from './components/AiGenerator'
import ExploreSection from './components/ExploreSection'
import RandomQuote from './components/RandomQuote'
import UnsaidFeelings from './components/UnsaidFeelings'
import SavedFeelings from './components/SavedFeelings'
import SubmitFeelingForm from './components/SubmitFeelingForm'
import OurStory from './components/OurStory'
import Footer from './components/Footer'
import AuthModal from './components/AuthModal'
import MySeRuh from './components/MySeRuh'
import AdminApp from './admin/AdminApp'

function routeFromHash() {
  const h = window.location.hash
  if (h.startsWith('#/admin')) return 'admin'
  if (h.startsWith('#/me')) return 'me'
  return 'public'
}

export default function App() {
  const [route, setRoute] = useState(routeFromHash())

  useEffect(() => {
    const onHash = () => setRoute(routeFromHash())
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  if (route === 'admin') {
    return (
      <UiProvider>
        <AdminApp />
      </UiProvider>
    )
  }

  return (
    <UiProvider>
      <AuthProvider>
        <DataProvider>
          {route === 'me' ? (
            <>
              <Navbar />
              <MySeRuh />
              <Footer />
            </>
          ) : (
            <>
              <Navbar />
              <main>
                <Hero />
                <FeelingForYou />
                <TodaysFeeling />
                <AiGenerator />
                <ExploreSection />
                <RandomQuote />
                <UnsaidFeelings />
                <SavedFeelings />
                <SubmitFeelingForm />
                <OurStory />
              </main>
              <Footer />
            </>
          )}
          <AuthModal />
        </DataProvider>
      </AuthProvider>
    </UiProvider>
  )
}
